
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    // Get the Mapbox API key from environment variable
    const MAPBOX_API_KEY = Deno.env.get('MAPBOX_API_KEY')
    
    if (!MAPBOX_API_KEY) {
      console.error("Mapbox API key not found in environment variables");
      return new Response(
        JSON.stringify({ error: 'Mapbox API key not configured' }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 500 
        }
      )
    }

    // Return the API key in the response
    return new Response(
      JSON.stringify({ 
        key: MAPBOX_API_KEY 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    )
  } catch (error) {
    console.error("Error in get-mapbox-key function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    )
  }
})

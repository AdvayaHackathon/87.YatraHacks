
export interface ModelInfo {
  id: number;
  name: string;
  location: string;
  period: string;
  description: string;
  image: string;
  downloadSize: string;
  availableOffline: boolean;
}

export const culturalModels: ModelInfo[] = [
  {
    id: 1,
    name: "Taj Mahal",
    location: "Agra, India",
    period: "17th Century",
    description: "The iconic marble mausoleum built by Emperor Shah Jahan in memory of his wife Mumtaz Mahal.",
    image: "https://images.unsplash.com/photo-1564507592333-c60657eea523?auto=format&fit=crop&q=80&w=600&h=400",
    downloadSize: "85 MB",
    availableOffline: true
  },
  {
    id: 2,
    name: "Khajuraho Temples",
    location: "Madhya Pradesh, India",
    period: "10th-11th Century",
    description: "Famous for their nagara-style architectural symbolism and erotic sculptures.",
    image: "https://images.unsplash.com/photo-1553686613-6fb6f371d1c7?auto=format&fit=crop&q=80&w=600&h=400",
    downloadSize: "120 MB",
    availableOffline: false
  },
  {
    id: 3,
    name: "Hampi Ruins",
    location: "Karnataka, India",
    period: "14th-16th Century",
    description: "The ruins of Vijayanagara Empire featuring stunning temples, royal complexes and more.",
    image: "https://images.unsplash.com/photo-1633920736456-dcab38b77a90?auto=format&fit=crop&q=80&w=600&h=400",
    downloadSize: "95 MB",
    availableOffline: true
  },
  {
    id: 4,
    name: "Petra",
    location: "Ma'an Governorate, Jordan",
    period: "312 BCE - 106 CE",
    description: "An ancient city famous for its rock-cut architecture and water conduit system, also known as the Rose City.",
    image: "https://images.unsplash.com/photo-1563177682-6684f9750f5a?auto=format&fit=crop&q=80&w=600&h=400",
    downloadSize: "110 MB",
    availableOffline: false
  }
];

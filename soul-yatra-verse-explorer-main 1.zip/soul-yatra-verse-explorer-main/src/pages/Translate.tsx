
import { useState } from "react";
import { ArrowRight, Volume2, Copy, RotateCw, Languages } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";

// Sample language options
const languages = [
  { code: "en", name: "English" },
  { code: "es", name: "Spanish" },
  { code: "fr", name: "French" },
  { code: "de", name: "German" },
  { code: "it", name: "Italian" },
  { code: "pt", name: "Portuguese" },
  { code: "ru", name: "Russian" },
  { code: "ja", name: "Japanese" },
  { code: "zh", name: "Chinese (Simplified)" },
  { code: "ar", name: "Arabic" },
  { code: "hi", name: "Hindi" },
  { code: "ko", name: "Korean" },
];

// Sample common phrases
const commonPhrases = [
  { phrase: "Hello", translation: "你好 (Nǐ hǎo)" },
  { phrase: "Thank you", translation: "谢谢 (Xièxiè)" },
  { phrase: "Excuse me", translation: "对不起 (Duìbùqǐ)" },
  { phrase: "How much?", translation: "多少钱？ (Duōshǎo qián?)" },
  { phrase: "Where is...?", translation: "...在哪里？ (...zài nǎlǐ?)" },
  { phrase: "I don't understand", translation: "我不明白 (Wǒ bù míngbái)" },
];

const Translate = () => {
  const [sourceText, setSourceText] = useState("");
  const [sourceLanguage, setSourceLanguage] = useState("en");
  const [targetLanguage, setTargetLanguage] = useState("zh");
  const [translatedText, setTranslatedText] = useState("");
  const [isTranslating, setIsTranslating] = useState(false);
  
  const handleTranslate = () => {
    if (!sourceText.trim()) return;
    
    setIsTranslating(true);
    
    // Simulate API call delay
    setTimeout(() => {
      // In a real app, this would call a translation API
      setTranslatedText("这是一个翻译示例。在实际应用中，这将通过集成翻译API来生成。");
      setIsTranslating(false);
    }, 1500);
  };
  
  const swapLanguages = () => {
    const temp = sourceLanguage;
    setSourceLanguage(targetLanguage);
    setTargetLanguage(temp);
    setSourceText(translatedText);
    setTranslatedText(sourceText);
  };
  
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    // In a real app, you would show a toast notification here
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Language Translation</h1>
          <p className="text-gray-600">
            Break language barriers and communicate effectively with local translations
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex flex-col md:flex-row justify-between mb-6 gap-4">
                <div className="w-full md:w-5/12">
                  <Select value={sourceLanguage} onValueChange={setSourceLanguage}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select source language" />
                    </SelectTrigger>
                    <SelectContent>
                      {languages.map((lang) => (
                        <SelectItem key={lang.code} value={lang.code}>
                          {lang.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex items-center justify-center">
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    onClick={swapLanguages}
                    className="rounded-full hover:bg-gray-100"
                  >
                    <ArrowRight className="h-5 w-5" />
                  </Button>
                </div>
                
                <div className="w-full md:w-5/12">
                  <Select value={targetLanguage} onValueChange={setTargetLanguage}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select target language" />
                    </SelectTrigger>
                    <SelectContent>
                      {languages.map((lang) => (
                        <SelectItem key={lang.code} value={lang.code}>
                          {lang.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Textarea
                    placeholder="Enter text to translate..."
                    className="h-48 resize-none"
                    value={sourceText}
                    onChange={(e) => setSourceText(e.target.value)}
                  />
                  <div className="flex justify-between mt-2">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => setSourceText("")}
                      className="text-gray-500"
                    >
                      Clear
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-8 w-8"
                      onClick={() => console.log("Voice input")}
                    >
                      <Volume2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                <div>
                  <div className="relative">
                    <Textarea
                      placeholder="Translation will appear here..."
                      className="h-48 resize-none"
                      value={translatedText}
                      readOnly
                    />
                    {isTranslating && (
                      <div className="absolute inset-0 bg-white/80 flex items-center justify-center">
                        <RotateCw className="h-6 w-6 animate-spin text-soul-orange" />
                      </div>
                    )}
                  </div>
                  <div className="flex justify-between mt-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => copyToClipboard(translatedText)}
                      className="text-gray-500"
                      disabled={!translatedText}
                    >
                      <Copy className="h-4 w-4 mr-1" />
                      Copy
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => console.log("Text to speech")}
                      disabled={!translatedText}
                    >
                      <Volume2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
              
              <div className="mt-6 flex justify-center">
                <Button 
                  onClick={handleTranslate} 
                  disabled={isTranslating || !sourceText.trim()}
                  className="bg-soul-orange hover:bg-soul-orange/90 px-8"
                >
                  {isTranslating ? (
                    <>
                      <RotateCw className="h-4 w-4 mr-2 animate-spin" />
                      Translating...
                    </>
                  ) : (
                    "Translate"
                  )}
                </Button>
              </div>
            </div>
          </div>
          
          <div>
            <div className="bg-white rounded-lg shadow-md p-6 mb-6">
              <div className="flex items-center mb-4">
                <Languages className="h-5 w-5 text-soul-maroon mr-2" />
                <h3 className="font-semibold">Common Phrases</h3>
              </div>
              
              <div className="space-y-4">
                {commonPhrases.map((item, index) => (
                  <div key={index} className="border-b pb-3 last:border-0 last:pb-0">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-medium">{item.phrase}</p>
                        <p className="text-gray-600 text-sm">{item.translation}</p>
                      </div>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8"
                        onClick={() => console.log("Speak phrase")}
                      >
                        <Volume2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="font-semibold mb-3">Translation Features</h3>
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-start">
                  <div className="w-2 h-2 rounded-full bg-soul-orange mt-2 mr-2"></div>
                  <span>Real-time translation of 100+ languages</span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 rounded-full bg-soul-orange mt-2 mr-2"></div>
                  <span>Voice input and text-to-speech output</span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 rounded-full bg-soul-orange mt-2 mr-2"></div>
                  <span>Camera translation for signs and menus</span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 rounded-full bg-soul-orange mt-2 mr-2"></div>
                  <span>Offline translation packs for travel</span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 rounded-full bg-soul-orange mt-2 mr-2"></div>
                  <span>Cultural context and local idioms</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Translate;


import { useState } from "react";
import { Bookmark, MapPin, Calendar, Clock, Trash2, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";

// Sample saved items
const savedItems = {
  places: [
    {
      id: 1,
      name: "Taj Mahal",
      location: "Agra, India",
      category: "UNESCO World Heritage",
      image: "https://images.unsplash.com/photo-1548013146-72479768bada?auto=format&fit=crop&q=80&w=600&h=400",
      savedDate: "2 weeks ago"
    },
    {
      id: 2,
      name: "The Great Wall",
      location: "Beijing, China",
      category: "UNESCO World Heritage",
      image: "https://images.unsplash.com/photo-1508804185872-d7badad00f7d?auto=format&fit=crop&q=80&w=600&h=400",
      savedDate: "1 month ago"
    }
  ],
  events: [
    {
      id: 1,
      title: "Diwali Festival of Lights",
      location: "New Delhi, India",
      date: "November, 2023",
      time: "All day",
      image: "https://images.unsplash.com/photo-1604423410570-dd9cec352eea?auto=format&fit=crop&q=80&w=600&h=400",
      savedDate: "3 days ago"
    }
  ],
  experiences: [
    {
      id: 1,
      title: "Traditional Pottery Workshop",
      location: "Jaipur, India",
      date: "Available daily",
      price: "₹1200",
      image: "https://images.unsplash.com/photo-1493106641515-6b5631de4bb9?auto=format&fit=crop&q=80&w=600&h=400",
      savedDate: "1 week ago"
    }
  ]
};

const Saved = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [activeTab, setActiveTab] = useState("places");
  
  // Filter items based on search term
  const filteredItems = {
    places: savedItems.places.filter(place => 
      place.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      place.location.toLowerCase().includes(searchTerm.toLowerCase())
    ),
    events: savedItems.events.filter(event => 
      event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.location.toLowerCase().includes(searchTerm.toLowerCase())
    ),
    experiences: savedItems.experiences.filter(exp => 
      exp.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      exp.location.toLowerCase().includes(searchTerm.toLowerCase())
    )
  };

  const handleRemoveItem = (id: number, type: string) => {
    console.log(`Remove ${type} item with id ${id}`);
    // In a real app, this would remove the item from the saved items
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Your Saved Items</h1>
          <p className="text-gray-600">
            Access your bookmarked heritage sites, events, and cultural experiences
          </p>
        </div>
        
        <div className="relative mb-6">
          <Input
            type="text"
            placeholder="Search your saved items..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
        </div>
        
        <Tabs defaultValue="places" onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="places" className="flex items-center">
              <Bookmark className="h-4 w-4 mr-1" />
              Places
              <span className="ml-1 bg-gray-200 text-gray-700 text-xs rounded-full px-2">
                {filteredItems.places.length}
              </span>
            </TabsTrigger>
            <TabsTrigger value="events" className="flex items-center">
              <Calendar className="h-4 w-4 mr-1" />
              Events
              <span className="ml-1 bg-gray-200 text-gray-700 text-xs rounded-full px-2">
                {filteredItems.events.length}
              </span>
            </TabsTrigger>
            <TabsTrigger value="experiences" className="flex items-center">
              <MapPin className="h-4 w-4 mr-1" />
              Experiences
              <span className="ml-1 bg-gray-200 text-gray-700 text-xs rounded-full px-2">
                {filteredItems.experiences.length}
              </span>
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="places">
            {filteredItems.places.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredItems.places.map(place => (
                  <div key={place.id} className="cultural-card overflow-hidden">
                    <div className="relative h-48 overflow-hidden">
                      <img 
                        src={place.image} 
                        alt={place.name} 
                        className="w-full h-full object-cover hover:scale-110 transition-transform duration-500"
                      />
                      <div className="absolute top-3 right-3 bg-white/80 text-soul-maroon text-xs px-2 py-1 rounded">
                        Saved {place.savedDate}
                      </div>
                    </div>
                    
                    <div className="p-4">
                      <div className="text-xs font-medium text-soul-maroon mb-1">
                        {place.category}
                      </div>
                      <h3 className="text-xl font-semibold mb-2">{place.name}</h3>
                      <div className="flex items-center text-gray-600 text-sm mb-4">
                        <MapPin className="h-4 w-4 mr-1" />
                        {place.location}
                      </div>
                      
                      <div className="flex justify-between">
                        <Button variant="outline" className="border-soul-teal text-soul-teal hover:bg-soul-teal/10">
                          View Details
                        </Button>
                        <Button 
                          variant="ghost" 
                          className="text-red-500 hover:text-red-600 hover:bg-red-50"
                          onClick={() => handleRemoveItem(place.id, 'place')}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-gray-50 rounded-lg">
                <Bookmark className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                <h3 className="text-xl font-semibold mb-2">No saved places</h3>
                <p className="text-gray-600 mb-4">
                  {searchTerm ? "No places match your search term." : "Start exploring and bookmark places you'd like to visit."}
                </p>
                <Button className="bg-soul-orange hover:bg-soul-orange/90">
                  Explore Heritage Sites
                </Button>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="events">
            {filteredItems.events.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredItems.events.map(event => (
                  <div key={event.id} className="cultural-card overflow-hidden">
                    <div className="relative h-48 overflow-hidden">
                      <img 
                        src={event.image} 
                        alt={event.title} 
                        className="w-full h-full object-cover hover:scale-110 transition-transform duration-500"
                      />
                      <div className="absolute top-3 right-3 bg-white/80 text-soul-maroon text-xs px-2 py-1 rounded">
                        Saved {event.savedDate}
                      </div>
                    </div>
                    
                    <div className="p-4">
                      <h3 className="text-xl font-semibold mb-2">{event.title}</h3>
                      
                      <div className="flex flex-col space-y-2 mb-4">
                        <div className="flex items-center text-gray-600 text-sm">
                          <MapPin className="h-4 w-4 mr-1 text-soul-teal" />
                          {event.location}
                        </div>
                        <div className="flex items-center text-gray-600 text-sm">
                          <Calendar className="h-4 w-4 mr-1 text-soul-teal" />
                          {event.date}
                        </div>
                        <div className="flex items-center text-gray-600 text-sm">
                          <Clock className="h-4 w-4 mr-1 text-soul-teal" />
                          {event.time}
                        </div>
                      </div>
                      
                      <div className="flex justify-between">
                        <Button variant="outline" className="border-soul-teal text-soul-teal hover:bg-soul-teal/10">
                          View Details
                        </Button>
                        <Button 
                          variant="ghost" 
                          className="text-red-500 hover:text-red-600 hover:bg-red-50"
                          onClick={() => handleRemoveItem(event.id, 'event')}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-gray-50 rounded-lg">
                <Calendar className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                <h3 className="text-xl font-semibold mb-2">No saved events</h3>
                <p className="text-gray-600 mb-4">
                  {searchTerm ? "No events match your search term." : "Save cultural events you plan to attend."}
                </p>
                <Button className="bg-soul-teal hover:bg-soul-teal/90">
                  Browse Cultural Events
                </Button>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="experiences">
            {filteredItems.experiences.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredItems.experiences.map(exp => (
                  <div key={exp.id} className="cultural-card overflow-hidden">
                    <div className="relative h-48 overflow-hidden">
                      <img 
                        src={exp.image} 
                        alt={exp.title} 
                        className="w-full h-full object-cover hover:scale-110 transition-transform duration-500"
                      />
                      <div className="absolute top-3 right-3 bg-white/80 text-soul-maroon text-xs px-2 py-1 rounded">
                        Saved {exp.savedDate}
                      </div>
                    </div>
                    
                    <div className="p-4">
                      <h3 className="text-xl font-semibold mb-2">{exp.title}</h3>
                      
                      <div className="flex flex-col space-y-2 mb-4">
                        <div className="flex items-center text-gray-600 text-sm">
                          <MapPin className="h-4 w-4 mr-1 text-soul-orange" />
                          {exp.location}
                        </div>
                        <div className="flex items-center text-gray-600 text-sm">
                          <Calendar className="h-4 w-4 mr-1 text-soul-orange" />
                          {exp.date}
                        </div>
                        <div className="flex items-center text-gray-600 text-sm font-medium">
                          Price: {exp.price}
                        </div>
                      </div>
                      
                      <div className="flex justify-between">
                        <Button className="bg-soul-orange hover:bg-soul-orange/90">
                          Book Now
                        </Button>
                        <Button 
                          variant="ghost" 
                          className="text-red-500 hover:text-red-600 hover:bg-red-50"
                          onClick={() => handleRemoveItem(exp.id, 'experience')}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-gray-50 rounded-lg">
                <MapPin className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                <h3 className="text-xl font-semibold mb-2">No saved experiences</h3>
                <p className="text-gray-600 mb-4">
                  {searchTerm ? "No experiences match your search term." : "Save cultural experiences you'd like to try."}
                </p>
                <Button className="bg-soul-maroon hover:bg-soul-maroon/90">
                  Discover Experiences
                </Button>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </main>
      
      <Footer />
    </div>
  );
};

export default Saved;

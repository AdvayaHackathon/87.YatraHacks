
import { useState } from "react";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import ToolkitHeader from "@/components/ToolkitHeader";
import ToolkitTabs from "@/components/ToolkitTabs";
import OfflineContentGrid from "@/components/OfflineContentGrid";
import EnhancedOfflineExperience from "@/components/EnhancedOfflineExperience";
import { useToast } from "@/hooks/use-toast";

const CulturalToolkit = () => {
  const [isOfflineMode, setIsOfflineMode] = useState(false);
  const { toast } = useToast();
  
  const toggleOfflineMode = () => {
    setIsOfflineMode(!isOfflineMode);
    
    toast({
      title: isOfflineMode ? "Online Mode Activated" : "Offline Mode Activated",
      description: isOfflineMode 
        ? "You're now connected and can access all SoulYatra features." 
        : "Downloaded content available for offline use. Some features limited.",
      duration: 3000
    });
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <ToolkitHeader 
          isOfflineMode={isOfflineMode} 
          toggleOfflineMode={toggleOfflineMode} 
        />
        
        <ToolkitTabs />
        
        <OfflineContentGrid />
        
        <EnhancedOfflineExperience />
      </main>
      
      <Footer />
    </div>
  );
};

export default CulturalToolkit;


import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { 
  MapPin,
  Globe,
  Calendar,
  Compass,
  Headphones,
  Clock,
  Camera,
  UserCheck,
  Layers
} from "lucide-react";
import Navigation from "@/components/Navigation";
import Hero from "@/components/Hero";
import FeaturedDestinations from "@/components/FeaturedDestinations";
import CulturalExperiences from "@/components/CulturalExperiences";
import FeaturesSection from "@/components/FeaturesSection";
import ChatbotPreview from "@/components/ChatbotPreview";
import TimeTravelPreview from "@/components/TimeTravelPreview";
import ARVRPreview from "@/components/ARVRPreview";
import Footer from "@/components/Footer";

const Index = () => {
  const [showAnimation, setShowAnimation] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    // Enable animation after a small delay for better page load performance
    const timer = setTimeout(() => {
      setShowAnimation(true);
    }, 300);
    
    return () => clearTimeout(timer);
  }, []);

  const handleFeatureClick = (feature: string) => {
    switch(feature) {
      case "map": 
        navigate("/map");
        break;
      case "translate":
        navigate("/translate");
        break;
      case "events":
        navigate("/events");
        break;
      case "explore":
        navigate("/explore");
        break;
      default:
        break;
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      <main className={`flex-grow transition-opacity duration-700 ${showAnimation ? "opacity-100" : "opacity-0"}`}>
        <Hero />
        <FeaturedDestinations />
        <CulturalExperiences />
        <FeaturesSection />
        <TimeTravelPreview />
        <ARVRPreview />
      </main>
      <ChatbotPreview />
      <Footer />
    </div>
  );
};

export default Index;


import { useState } from "react";
import { Calendar as CalendarIcon, Search, MapPin, Clock, Filter, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";

// Sample events data
const events = [
  {
    id: 1,
    title: "Diwali Festival of Lights",
    location: "New Delhi, India",
    date: "November, 2023",
    time: "All day",
    image: "https://images.unsplash.com/photo-1604423410570-dd9cec352eea?auto=format&fit=crop&q=80&w=600&h=400",
    category: "Festival",
    description: "Celebrate the victory of light over darkness with beautiful lamps, fireworks, and traditional ceremonies."
  },
  {
    id: 2,
    title: "Chinese New Year Parade",
    location: "Beijing, China",
    date: "February, 2023",
    time: "10:00 AM - 2:00 PM",
    image: "https://images.unsplash.com/photo-1568393691622-c7ba131d63b4?auto=format&fit=crop&q=80&w=600&h=400",
    category: "Parade",
    description: "Welcome the Lunar New Year with dragon dances, red lanterns, and traditional performances."
  },
  {
    id: 3,
    title: "Day of the Dead Celebrations",
    location: "Mexico City, Mexico",
    date: "November, 2023",
    time: "All day",
    image: "https://images.unsplash.com/photo-1572374361357-3e58fcd545d1?auto=format&fit=crop&q=80&w=600&h=400",
    category: "Cultural",
    description: "Honor deceased loved ones with colorful altars, marigold flowers, and skull-shaped treats."
  },
  {
    id: 4,
    title: "Carnival of Venice",
    location: "Venice, Italy",
    date: "February, 2023",
    time: "Various times",
    image: "https://images.unsplash.com/photo-1569154934650-78c288324482?auto=format&fit=crop&q=80&w=600&h=400",
    category: "Festival",
    description: "Experience the magic of elaborate masks and costumes during this historic Venetian celebration."
  },
  {
    id: 5,
    title: "Songkran Water Festival",
    location: "Bangkok, Thailand",
    date: "April, 2023",
    time: "All day",
    image: "https://images.unsplash.com/photo-1619143921821-4fa70c9a1bc7?auto=format&fit=crop&q=80&w=600&h=400",
    category: "Festival",
    description: "Join in Thailand's traditional New Year celebrations with water fights and spiritual cleansing."
  },
  {
    id: 6,
    title: "Oktoberfest",
    location: "Munich, Germany",
    date: "September, 2023",
    time: "10:00 AM - 10:30 PM",
    image: "https://images.unsplash.com/photo-1505489304219-85ce17010209?auto=format&fit=crop&q=80&w=600&h=400",
    category: "Festival",
    description: "Enjoy Bavarian beer, food, music and traditional festivities at the world's largest folk festival."
  }
];

const Events = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  const [selectedFilters, setSelectedFilters] = useState<string[]>([]);
  
  const categories = ["Festival", "Parade", "Cultural", "Religious", "Music", "Food"];

  const toggleFilter = (filter: string) => {
    if (selectedFilters.includes(filter)) {
      setSelectedFilters(selectedFilters.filter(f => f !== filter));
    } else {
      setSelectedFilters([...selectedFilters, filter]);
    }
  };

  const clearFilters = () => {
    setSelectedFilters([]);
    setSelectedDate(undefined);
  };

  // Filter events based on search term, date, and categories
  const filteredEvents = events.filter(event => {
    const matchesSearch = event.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         event.location.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesFilters = selectedFilters.length === 0 || 
                          selectedFilters.includes(event.category);
    
    // This is a simplified date check - in a real app, this would be more precise
    const matchesDate = !selectedDate || event.date.includes(selectedDate.toLocaleString('default', { month: 'long' }));
    
    return matchesSearch && matchesFilters && matchesDate;
  });

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Cultural Events & Festivals</h1>
          <p className="text-gray-600">
            Discover traditional celebrations, festivals, and cultural events around the world
          </p>
        </div>
        
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-grow">
            <Input
              type="text"
              placeholder="Search events by name or location..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          </div>
          
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" className="w-full md:w-auto">
                <CalendarIcon className="mr-2 h-4 w-4" />
                {selectedDate ? (
                  selectedDate.toLocaleDateString('en-US', {
                    month: 'long',
                    year: 'numeric',
                  })
                ) : (
                  "Select month"
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0">
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                initialFocus
              />
            </PopoverContent>
          </Popover>
          
          <div className="flex items-center">
            <Button 
              variant="outline" 
              className="mr-2 flex items-center"
              onClick={() => document.getElementById('filterDrawer')?.classList.toggle('hidden')}
            >
              <Filter className="h-4 w-4 mr-1" />
              Filters
              {selectedFilters.length > 0 && (
                <span className="ml-1 bg-soul-orange text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {selectedFilters.length}
                </span>
              )}
            </Button>
            
            {(selectedFilters.length > 0 || selectedDate) && (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={clearFilters}
                className="text-gray-500 hover:text-gray-700"
              >
                Clear all
                <X className="h-3 w-3 ml-1" />
              </Button>
            )}
          </div>
        </div>
        
        <div id="filterDrawer" className="bg-gray-50 p-4 rounded-lg mb-6 hidden">
          <div className="flex justify-between items-center mb-3">
            <h3 className="font-medium">Filter by category</h3>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => document.getElementById('filterDrawer')?.classList.add('hidden')}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
          
          <div className="flex flex-wrap gap-2">
            {categories.map(category => (
              <Button
                key={category}
                variant={selectedFilters.includes(category) ? "default" : "outline"}
                size="sm"
                className={selectedFilters.includes(category) ? "bg-soul-teal hover:bg-soul-teal/90" : ""}
                onClick={() => toggleFilter(category)}
              >
                {category}
              </Button>
            ))}
          </div>
        </div>
        
        {(selectedFilters.length > 0 || selectedDate) && (
          <div className="flex flex-wrap gap-2 mb-6">
            {selectedFilters.map(filter => (
              <div key={filter} className="bg-gray-100 rounded-full px-3 py-1 text-sm flex items-center">
                {filter}
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-4 w-4 ml-1 hover:bg-transparent p-0" 
                  onClick={() => toggleFilter(filter)}
                >
                  <X className="h-3 w-3" />
                </Button>
              </div>
            ))}
            
            {selectedDate && (
              <div className="bg-gray-100 rounded-full px-3 py-1 text-sm flex items-center">
                {selectedDate.toLocaleDateString('en-US', {
                  month: 'long',
                  year: 'numeric',
                })}
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-4 w-4 ml-1 hover:bg-transparent p-0" 
                  onClick={() => setSelectedDate(undefined)}
                >
                  <X className="h-3 w-3" />
                </Button>
              </div>
            )}
          </div>
        )}
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredEvents.map(event => (
            <div key={event.id} className="cultural-card overflow-hidden">
              <div className="h-48 overflow-hidden">
                <img 
                  src={event.image} 
                  alt={event.title} 
                  className="w-full h-full object-cover hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute top-3 right-3 bg-soul-teal text-white text-xs px-2 py-1 rounded">
                  {event.category}
                </div>
              </div>
              
              <div className="p-4">
                <h3 className="text-xl font-semibold mb-2">{event.title}</h3>
                
                <div className="flex flex-col space-y-2 mb-3">
                  <div className="flex items-center text-gray-600 text-sm">
                    <MapPin className="h-4 w-4 mr-1 text-soul-maroon" />
                    {event.location}
                  </div>
                  <div className="flex items-center text-gray-600 text-sm">
                    <CalendarIcon className="h-4 w-4 mr-1 text-soul-maroon" />
                    {event.date}
                  </div>
                  <div className="flex items-center text-gray-600 text-sm">
                    <Clock className="h-4 w-4 mr-1 text-soul-maroon" />
                    {event.time}
                  </div>
                </div>
                
                <p className="text-gray-600 text-sm line-clamp-2 mb-4">
                  {event.description}
                </p>
                
                <div className="flex justify-between">
                  <Button variant="outline" className="text-soul-teal border-soul-teal hover:bg-soul-teal/10">
                    Learn More
                  </Button>
                  <Button className="bg-soul-teal hover:bg-soul-teal/90">
                    Add to Calendar
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {filteredEvents.length === 0 && (
          <div className="text-center py-12">
            <div className="text-4xl mb-4">📅</div>
            <h3 className="text-xl font-semibold mb-2">No events found</h3>
            <p className="text-gray-600 mb-4">
              Try adjusting your search, date selection, or filters.
            </p>
            <Button onClick={clearFilters} className="bg-soul-teal hover:bg-soul-teal/90">
              Clear all filters
            </Button>
          </div>
        )}
      </main>
      
      <Footer />
    </div>
  );
};

export default Events;

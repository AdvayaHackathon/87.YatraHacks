
import { useState, useEffect, useRef } from "react";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MapPin, Search, RotateCw, Layers, Plus, Minus } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/components/ui/use-toast";
import mapboxgl from "mapbox-gl";
import "mapbox-gl/dist/mapbox-gl.css";

const Map = () => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const [mapKey, setMapKey] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [errorMsg, setErrorMsg] = useState("");

  // Fetch Mapbox key from Supabase edge function
  useEffect(() => {
    const fetchMapboxKey = async () => {
      try {
        console.log("Fetching Mapbox key from edge function...");
        const { data, error } = await supabase.functions.invoke('get-mapbox-key');
        
        if (error) {
          console.error("Error fetching Mapbox key:", error);
          setErrorMsg("Failed to load map. Please try again later.");
          setLoading(false);
          return;
        }
        
        if (data?.key) {
          console.log("Mapbox key retrieved successfully");
          setMapKey(data.key);
        } else {
          console.error("Mapbox key not found in response:", data);
          setErrorMsg("Map configuration not found.");
          setLoading(false);
        }
      } catch (error) {
        console.error("Exception in fetchMapboxKey:", error);
        setErrorMsg("Failed to load map. Please try again later.");
        setLoading(false);
      }
    };
    
    fetchMapboxKey();
  }, []);

  // Initialize map when mapKey is available
  useEffect(() => {
    if (!mapKey || !mapContainer.current || map.current) return;

    try {
      console.log("Initializing Mapbox map with key:", mapKey.substring(0, 5) + "...");
      // Initialize map
      mapboxgl.accessToken = mapKey;
      
      map.current = new mapboxgl.Map({
        container: mapContainer.current,
        style: 'mapbox://styles/mapbox/light-v11',
        projection: 'globe',
        zoom: 1.5,
        center: [30, 15],
        pitch: 45,
      });

      // Add navigation controls
      map.current.addControl(
        new mapboxgl.NavigationControl({
          visualizePitch: true,
        }),
        'top-right'
      );

      // Disable scroll zoom for smoother experience
      map.current.scrollZoom.disable();

      // Add atmosphere and fog effects
      map.current.on('style.load', () => {
        map.current?.setFog({
          color: 'rgb(255, 255, 255)',
          'high-color': 'rgb(200, 200, 225)',
          'horizon-blend': 0.2,
        });
        
        setLoading(false);
      });

      // Rotation animation settings
      const secondsPerRevolution = 240;
      const maxSpinZoom = 5;
      const slowSpinZoom = 3;
      let userInteracting = false;
      let spinEnabled = true;

      // Spin globe function
      function spinGlobe() {
        if (!map.current) return;
        
        const zoom = map.current.getZoom();
        if (spinEnabled && !userInteracting && zoom < maxSpinZoom) {
          let distancePerSecond = 360 / secondsPerRevolution;
          if (zoom > slowSpinZoom) {
            const zoomDif = (maxSpinZoom - zoom) / (maxSpinZoom - slowSpinZoom);
            distancePerSecond *= zoomDif;
          }
          const center = map.current.getCenter();
          center.lng -= distancePerSecond;
          map.current.easeTo({ center, duration: 1000, easing: (n) => n });
        }
      }

      // Event listeners for interaction
      map.current.on('mousedown', () => {
        userInteracting = true;
      });
      
      map.current.on('dragstart', () => {
        userInteracting = true;
      });
      
      map.current.on('mouseup', () => {
        userInteracting = false;
        spinGlobe();
      });
      
      map.current.on('touchend', () => {
        userInteracting = false;
        spinGlobe();
      });

      map.current.on('moveend', () => {
        spinGlobe();
      });

      // Start the globe spinning
      spinGlobe();
    } catch (error) {
      console.error("Error initializing map:", error);
      setErrorMsg("Failed to initialize map. Please try again later.");
      setLoading(false);
    }

    // Cleanup
    return () => {
      map.current?.remove();
    };
  }, [mapKey]);

  // Handle search submission
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!searchQuery.trim()) {
      toast({
        title: "Search Error",
        description: "Please enter a location to search",
        variant: "destructive"
      });
      return;
    }
    
    if (!map.current || !mapKey) {
      setErrorMsg("Map not initialized. Please try again.");
      return;
    }
    
    // Geocoding API endpoint
    const geocodingUrl = `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(searchQuery)}.json?access_token=${mapKey}&limit=1`;
    
    fetch(geocodingUrl)
      .then(response => {
        if (!response.ok) {
          throw new Error(`Network response error: ${response.status}`);
        }
        return response.json();
      })
      .then(data => {
        if (data.features && data.features.length > 0) {
          const [longitude, latitude] = data.features[0].center;
          
          // Fly to the location
          map.current?.flyTo({
            center: [longitude, latitude],
            zoom: 8,
            duration: 2000,
            essential: true
          });
          
          // Add a marker
          new mapboxgl.Marker({ color: '#E94560' })
            .setLngLat([longitude, latitude])
            .setPopup(new mapboxgl.Popup().setHTML(`<h3>${data.features[0].place_name}</h3>`))
            .addTo(map.current);
            
          toast({
            title: "Location Found",
            description: `Navigating to ${data.features[0].place_name}`,
          });
        } else {
          toast({
            title: "Search Error",
            description: "Location not found. Please try another search.",
            variant: "destructive"
          });
        }
      })
      .catch(error => {
        console.error("Search error:", error);
        toast({
          title: "Search Error",
          description: "Search failed. Please try again.",
          variant: "destructive"
        });
      });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-grow">
        <div className="container mx-auto px-4 py-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">
              <span className="bg-gradient-to-r from-soul-maroon to-soul-orange bg-clip-text text-transparent">
                Cultural Map Explorer
              </span>
            </h1>
            <p className="text-gray-600">Discover UNESCO sites, festivals, and cultural landmarks worldwide</p>
          </div>
          
          {/* Search bar */}
          <form onSubmit={handleSearch} className="relative max-w-xl mb-6">
            <Input
              type="text"
              placeholder="Search for a city, country, or cultural site..."
              className="pl-4 pr-12 py-6 rounded-lg bg-white shadow-md"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Button 
              type="submit" 
              size="icon" 
              className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-soul-orange hover:bg-soul-orange/90 rounded-full h-10 w-10"
            >
              <Search className="h-5 w-5" />
            </Button>
          </form>
          
          {errorMsg && (
            <div className="bg-red-50 text-red-600 p-3 rounded-lg mb-4">
              {errorMsg}
            </div>
          )}
          
          {/* Map container */}
          <div className="relative w-full h-[70vh] rounded-lg overflow-hidden shadow-lg">
            {loading ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-100 rounded-lg">
                <Skeleton className="w-full h-full" />
                <div className="absolute flex items-center justify-center">
                  <RotateCw className="h-10 w-10 text-soul-teal animate-spin" />
                  <span className="ml-2 text-lg font-medium text-soul-teal">Loading map...</span>
                </div>
              </div>
            ) : (
              <>
                <div ref={mapContainer} className="absolute inset-0 rounded-lg" />
                <div className="absolute inset-0 pointer-events-none bg-gradient-to-b from-transparent to-background/10 rounded-lg" />
                
                {/* Map controls */}
                <div className="absolute bottom-5 left-5 flex flex-col space-y-2">
                  <Button size="icon" variant="secondary" className="bg-white/90 hover:bg-white">
                    <Plus className="h-5 w-5" />
                  </Button>
                  <Button size="icon" variant="secondary" className="bg-white/90 hover:bg-white">
                    <Minus className="h-5 w-5" />
                  </Button>
                </div>
                
                <div className="absolute bottom-5 right-5">
                  <Button variant="secondary" className="bg-white/90 hover:bg-white">
                    <Layers className="h-5 w-5 mr-2" />
                    <span>Layers</span>
                  </Button>
                </div>
              </>
            )}
          </div>
          
          {/* Legend */}
          <div className="mt-6 grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="flex items-center p-3 bg-white rounded-lg shadow">
              <MapPin className="h-5 w-5 text-soul-maroon mr-2" />
              <span>UNESCO Heritage Sites</span>
            </div>
            <div className="flex items-center p-3 bg-white rounded-lg shadow">
              <MapPin className="h-5 w-5 text-soul-orange mr-2" />
              <span>Cultural Festivals</span>
            </div>
            <div className="flex items-center p-3 bg-white rounded-lg shadow">
              <MapPin className="h-5 w-5 text-soul-teal mr-2" />
              <span>Traditional Cuisine</span>
            </div>
            <div className="flex items-center p-3 bg-white rounded-lg shadow">
              <MapPin className="h-5 w-5 text-soul-gold mr-2" />
              <span>Historical Landmarks</span>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Map;

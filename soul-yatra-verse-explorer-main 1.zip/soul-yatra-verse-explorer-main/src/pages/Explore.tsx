
import { useState, useEffect } from "react";
import { Search, Filter, MapPin, X, Clock, Calendar, Star, Info, User, ChevronRight, Heart, BookmarkPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { useToast } from "@/hooks/use-toast";

// Sample data for heritage sites
const heritageSites = [
  {
    id: 1,
    name: "Taj Mahal",
    location: "Agra, India",
    category: "UNESCO World Heritage",
    image: "https://images.unsplash.com/photo-1548013146-72479768bada?auto=format&fit=crop&q=80&w=600&h=400",
    description: "A magnificent mausoleum built by Emperor Shah Jahan in memory of his wife Mumtaz Mahal.",
    rating: 4.9,
    distance: "5.2 km",
    visitDuration: "2-3 hours",
    bestTimeToVisit: "Early morning",
    entryFee: "₹1100 for foreigners, ₹50 for Indians",
    openingHours: "Sunrise to sunset (Closed on Fridays)",
    facilities: ["Guided tours", "Wheelchair access", "Photography allowed"],
    nearbyAttractions: ["Agra Fort", "Mehtab Bagh", "Itimad-ud-Daulah"],
    historicalSignificance: "Built between 1631-1648 as a mausoleum for Mumtaz Mahal, the favorite wife of Emperor Shah Jahan. It's considered the finest example of Mughal architecture.",
    localTips: ["Visit at sunrise to avoid crowds", "The marble changes color throughout the day"],
    reviews: [
      { user: "Travel_Enthusiast", rating: 5, comment: "Absolutely breathtaking, a must-visit!" },
      { user: "HistoryBuff42", rating: 5, comment: "The architecture and story behind it is fascinating." },
      { user: "WorldExplorer", rating: 4, comment: "Beautiful but very crowded. Go early!" }
    ]
  },
  {
    id: 2,
    name: "The Great Wall",
    location: "Beijing, China",
    category: "UNESCO World Heritage",
    image: "https://images.unsplash.com/photo-1508804185872-d7badad00f7d?auto=format&fit=crop&q=80&w=600&h=400",
    description: "An ancient fortification built along the northern borders of China to protect against invasions.",
    rating: 4.8,
    distance: "120 km",
    visitDuration: "3-5 hours",
    bestTimeToVisit: "April-May or September-October",
    entryFee: "¥40-60 depending on section",
    openingHours: "7:30 AM - 5:30 PM",
    facilities: ["Cable car", "Souvenir shops", "Restrooms"],
    nearbyAttractions: ["Ming Tombs", "Summer Palace"],
    historicalSignificance: "Built from the 3rd century BC to the 17th century AD, it was constructed to protect Chinese states against raids and invasions.",
    localTips: ["The Mutianyu section is less crowded than Badaling", "Wear comfortable shoes for walking"],
    reviews: [
      { user: "AdventureSeeker", rating: 5, comment: "A bucket list item that doesn't disappoint!" },
      { user: "CultureLover", rating: 4, comment: "Amazing historical monument, but prepare for a lot of climbing." }
    ]
  },
  {
    id: 3,
    name: "Machu Picchu",
    location: "Cusco Region, Peru",
    category: "UNESCO World Heritage",
    image: "https://images.unsplash.com/photo-1526392060635-9d6019884377?auto=format&fit=crop&q=80&w=600&h=400",
    description: "An ancient Incan citadel set high in the Andes Mountains, featuring incredible ruins and views.",
    rating: 4.9,
    distance: "75 km",
    visitDuration: "4-6 hours",
    bestTimeToVisit: "May to September (dry season)",
    entryFee: "S/152 for foreigners",
    openingHours: "6:00 AM - 5:30 PM",
    facilities: ["Guided tours", "Bus service", "Restrooms"],
    nearbyAttractions: ["Huayna Picchu", "Aguas Calientes", "Sacred Valley"],
    historicalSignificance: "Built in the 15th century as an estate for the Inca emperor Pachacuti, it was abandoned during the Spanish conquest.",
    localTips: ["Book tickets well in advance", "Consider the 4-day Inca Trail for a more immersive experience"],
    reviews: [
      { user: "HikingEnthusiast", rating: 5, comment: "The hike is challenging but the views are worth every step!" },
      { user: "PhotoJunkie", rating: 5, comment: "Pictures don't do it justice. Absolutely magical place." }
    ]
  },
  {
    id: 4,
    name: "Petra",
    location: "Ma'an Governorate, Jordan",
    category: "UNESCO World Heritage",
    image: "https://images.unsplash.com/photo-1563177682-6684f9750f5a?auto=format&fit=crop&q=80&w=600&h=400",
    description: "A historic city famous for its rock-cut architecture and water conduit system.",
    rating: 4.7,
    distance: "50 km",
    visitDuration: "1-2 days",
    bestTimeToVisit: "March-May or September-November",
    entryFee: "50 JOD for one-day pass",
    openingHours: "6:00 AM - 6:00 PM (summer), 6:00 AM - 4:00 PM (winter)",
    facilities: ["Horse and camel rides", "Souvenir shops", "Restaurants"],
    nearbyAttractions: ["Wadi Rum", "Dead Sea", "Little Petra"],
    historicalSignificance: "Established around 312 BC as the capital of the Nabataean Kingdom, it was an important junction for silk and spice trade routes.",
    localTips: ["Stay for Petra by Night", "The Treasury is just the beginning - explore further in"],
    reviews: [
      { user: "DesertTraveler", rating: 5, comment: "The Siq walk building up to the Treasury reveal is magical." },
      { user: "AncientHistory", rating: 4, comment: "Incredible place but very hot in summer. Bring water!" }
    ]
  },
  {
    id: 5,
    name: "Colosseum",
    location: "Rome, Italy",
    category: "UNESCO World Heritage",
    image: "https://images.unsplash.com/photo-1552832230-c0197dd311b5?auto=format&fit=crop&q=80&w=600&h=400",
    description: "An oval amphitheater in the center of Rome, built of concrete and sand.",
    rating: 4.7,
    distance: "35 km",
    visitDuration: "1-2 hours",
    bestTimeToVisit: "April-May or September-October",
    entryFee: "€16 combined ticket with Roman Forum and Palatine Hill",
    openingHours: "8:30 AM - 7:00 PM (varies by season)",
    facilities: ["Audio guides", "Guided tours", "Wheelchair access (limited)"],
    nearbyAttractions: ["Roman Forum", "Palatine Hill", "Arch of Constantine"],
    historicalSignificance: "Built between 70-80 AD, it was the largest amphitheater of the Roman Empire and could hold up to 80,000 spectators.",
    localTips: ["Buy combined tickets online to skip the line", "The underground tour is worth the extra cost"],
    reviews: [
      { user: "RomanHistory", rating: 5, comment: "Standing inside this ancient structure gives you chills thinking about its past." },
      { user: "EuropeTraveler", rating: 4, comment: "Iconic, but get the guided tour to really understand what you're seeing." }
    ]
  },
  {
    id: 6,
    name: "Angkor Wat",
    location: "Siem Reap, Cambodia",
    category: "UNESCO World Heritage",
    image: "https://images.unsplash.com/photo-1549867339-32d62524fc76?auto=format&fit=crop&q=80&w=600&h=400",
    description: "A temple complex and the largest religious monument in the world.",
    rating: 4.8,
    distance: "90 km",
    visitDuration: "1-3 days",
    bestTimeToVisit: "November to March (dry season)",
    entryFee: "$37 for one-day pass",
    openingHours: "5:00 AM - 6:00 PM",
    facilities: ["Bicycle rental", "Guided tours", "Restaurants nearby"],
    nearbyAttractions: ["Bayon Temple", "Ta Prohm", "Banteay Srei"],
    historicalSignificance: "Built in the early 12th century as a Hindu temple dedicated to Vishnu, it was gradually transformed into a Buddhist temple.",
    localTips: ["Wake up early for sunrise at Angkor Wat", "The three-day pass offers the best value for exploring the whole complex"],
    reviews: [
      { user: "AsiaExplorer", rating: 5, comment: "Sunrise at Angkor Wat is a life-changing experience." },
      { user: "TempleHunter", rating: 5, comment: "The detail in the stone carvings is mind-blowing. Plan several days here." }
    ]
  }
];

const Explore = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedFilters, setSelectedFilters] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState("all");
  const [selectedSite, setSelectedSite] = useState<number | null>(null);
  const [showFilterDrawer, setShowFilterDrawer] = useState(false);
  const [personalizedRecommendations, setPersonalizedRecommendations] = useState<boolean>(true);
  
  const { toast } = useToast();
  
  const filters = ["UNESCO World Heritage", "Historical", "Religious", "Natural", "Cultural Landscapes"];
  const popularSearches = ["Temples", "Palaces", "Forts", "Museums", "Ancient Ruins"];

  const toggleFilter = (filter: string) => {
    if (selectedFilters.includes(filter)) {
      setSelectedFilters(selectedFilters.filter(f => f !== filter));
    } else {
      setSelectedFilters([...selectedFilters, filter]);
    }
  };

  const clearFilters = () => {
    setSelectedFilters([]);
  };

  const togglePersonalizedRecommendations = () => {
    setPersonalizedRecommendations(!personalizedRecommendations);
    
    // Show toast notification
    toast({
      title: personalizedRecommendations ? "Personalized recommendations disabled" : "Personalized recommendations enabled",
      description: personalizedRecommendations 
        ? "You'll now see all heritage sites without personalization." 
        : "We'll customize suggestions based on your preferences and browsing history.",
      duration: 3000
    });
  };

  // Filter sites based on search term, selected filters, and active tab
  const filteredSites = heritageSites.filter(site => {
    const matchesSearch = site.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         site.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         site.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesFilters = selectedFilters.length === 0 || 
                          selectedFilters.includes(site.category);
    
    const matchesTab = activeTab === "all" || 
                      (activeTab === "popular" && site.rating > 4.7) ||
                      (activeTab === "nearby" && parseFloat(site.distance) < 100);
    
    return matchesSearch && matchesFilters && matchesTab;
  });

  const saveToFavorites = (id: number) => {
    toast({
      title: "Added to favorites",
      description: "This heritage site has been saved to your favorites.",
      duration: 3000
    });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Explore Heritage Sites</h1>
          <p className="text-gray-600">
            Discover cultural landmarks, monuments, and natural wonders from around the world
          </p>
        </div>
        
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-grow">
            <Input
              type="text"
              placeholder="Search by name or location..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          </div>
          
          <div className="flex items-center">
            <Button 
              variant="outline" 
              className="mr-2 flex items-center"
              onClick={() => setShowFilterDrawer(!showFilterDrawer)}
            >
              <Filter className="h-4 w-4 mr-1" />
              Filters
              {selectedFilters.length > 0 && (
                <span className="ml-1 bg-soul-orange text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {selectedFilters.length}
                </span>
              )}
            </Button>
            
            {selectedFilters.length > 0 && (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={clearFilters}
                className="text-gray-500 hover:text-gray-700"
              >
                Clear all
                <X className="h-3 w-3 ml-1" />
              </Button>
            )}
          </div>
        </div>
        
        {/* Popular Searches */}
        <div className="mb-6">
          <div className="text-sm text-gray-500 mb-2">Popular Searches:</div>
          <div className="flex flex-wrap gap-2">
            {popularSearches.map(term => (
              <Button 
                key={term} 
                variant="outline" 
                size="sm"
                className="bg-gray-50 hover:bg-gray-100"
                onClick={() => setSearchTerm(term)}
              >
                {term}
              </Button>
            ))}
          </div>
        </div>
        
        <div id="filterDrawer" className={`bg-gray-50 p-4 rounded-lg mb-6 ${showFilterDrawer ? 'block' : 'hidden'}`}>
          <div className="flex justify-between items-center mb-3">
            <h3 className="font-medium">Filter by category</h3>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => setShowFilterDrawer(false)}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
          
          <div className="flex flex-wrap gap-2">
            {filters.map(filter => (
              <Button
                key={filter}
                variant={selectedFilters.includes(filter) ? "default" : "outline"}
                size="sm"
                className={selectedFilters.includes(filter) ? "bg-soul-maroon hover:bg-soul-maroon/90" : ""}
                onClick={() => toggleFilter(filter)}
              >
                {filter}
              </Button>
            ))}
          </div>
          
          <div className="mt-4 pt-4 border-t border-gray-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="personalizedRecommendations" 
                  checked={personalizedRecommendations}
                  onCheckedChange={togglePersonalizedRecommendations}
                />
                <label 
                  htmlFor="personalizedRecommendations" 
                  className="text-sm font-medium leading-none cursor-pointer"
                >
                  Show personalized recommendations
                </label>
              </div>
              <Info className="h-4 w-4 text-gray-400" />
            </div>
          </div>
        </div>
        
        {selectedFilters.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-6">
            {selectedFilters.map(filter => (
              <div key={filter} className="bg-gray-100 rounded-full px-3 py-1 text-sm flex items-center">
                {filter}
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-4 w-4 ml-1 hover:bg-transparent p-0" 
                  onClick={() => toggleFilter(filter)}
                >
                  <X className="h-3 w-3" />
                </Button>
              </div>
            ))}
          </div>
        )}
        
        <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="mb-8">
          <TabsList className="bg-gray-100">
            <TabsTrigger value="all">All Sites</TabsTrigger>
            <TabsTrigger value="popular">Popular</TabsTrigger>
            <TabsTrigger value="nearby">Nearby</TabsTrigger>
            <TabsTrigger value="recommended">Recommended</TabsTrigger>
          </TabsList>
        </Tabs>
        
        {personalizedRecommendations && activeTab === "recommended" && (
          <div className="mb-8 bg-soul-cream/30 p-4 rounded-lg border border-soul-orange/20">
            <h3 className="text-lg font-semibold text-soul-maroon mb-2">
              Personalized Recommendations
            </h3>
            <p className="text-sm text-gray-600 mb-3">
              Based on your interests in historical architecture and religious sites:
            </p>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {heritageSites.slice(0, 3).map(site => (
                <div key={site.id} className="bg-white rounded-lg p-3 shadow-sm border border-gray-100">
                  <div className="text-xs font-medium text-soul-maroon mb-1">{site.category}</div>
                  <h4 className="font-medium mb-1">{site.name}</h4>
                  <div className="flex items-center text-gray-500 text-xs">
                    <MapPin className="h-3 w-3 mr-1" />
                    {site.location}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredSites.map(site => (
            <Card key={site.id} className="cultural-card overflow-hidden relative">
              <div className="h-48 overflow-hidden">
                <img 
                  src={site.image} 
                  alt={site.name} 
                  className="w-full h-full object-cover hover:scale-110 transition-transform duration-500"
                />
                <button
                  className="absolute top-3 right-3 bg-white rounded-full p-1 shadow-md hover:bg-gray-100 transition-colors"
                  onClick={() => saveToFavorites(site.id)}
                >
                  <BookmarkPlus className="h-4 w-4 text-soul-orange" />
                </button>
              </div>
              
              <CardContent className="p-4">
                <div className="text-xs font-medium text-soul-maroon mb-2">
                  {site.category}
                </div>
                <h3 className="text-xl font-semibold mb-1">{site.name}</h3>
                <div className="flex items-center text-gray-500 text-sm mb-3">
                  <MapPin className="h-4 w-4 mr-1" />
                  {site.location}
                </div>
                <p className="text-gray-600 text-sm line-clamp-2 mb-4">
                  {site.description}
                </p>
                
                <div className="grid grid-cols-2 gap-2 text-xs text-gray-500 mb-4">
                  <div className="flex items-center">
                    <Clock className="h-3 w-3 mr-1 text-soul-maroon" />
                    <span>{site.visitDuration}</span>
                  </div>
                  <div className="flex items-center">
                    <Star className="h-3 w-3 mr-1 text-soul-gold" fill="currentColor" />
                    <span>{site.rating} rating</span>
                  </div>
                  <div className="flex items-center">
                    <Calendar className="h-3 w-3 mr-1 text-soul-maroon" />
                    <span>{site.bestTimeToVisit}</span>
                  </div>
                  <div className="flex items-center">
                    <MapPin className="h-3 w-3 mr-1 text-soul-maroon" />
                    <span>{site.distance}</span>
                  </div>
                </div>
                
                <div className="flex justify-between">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="text-soul-orange border-soul-orange hover:bg-soul-orange/10"
                    onClick={() => setSelectedSite(site.id)}
                  >
                    Quick View
                  </Button>
                  <Button className="bg-soul-teal hover:bg-soul-teal/90" size="sm">
                    View Details
                    <ChevronRight className="h-3 w-3 ml-1" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        {filteredSites.length === 0 && (
          <div className="text-center py-12">
            <div className="text-4xl mb-4">🔍</div>
            <h3 className="text-xl font-semibold mb-2">No results found</h3>
            <p className="text-gray-600 mb-4">
              Try adjusting your search or filters to find what you're looking for.
            </p>
            <Button onClick={clearFilters} className="bg-soul-orange hover:bg-soul-orange/90">
              Clear all filters
            </Button>
          </div>
        )}
        
        {selectedSite && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-auto">
              <div className="sticky top-0 bg-white p-4 border-b flex justify-between items-center">
                <h3 className="font-bold text-xl">
                  {heritageSites.find(site => site.id === selectedSite)?.name}
                </h3>
                <Button variant="ghost" size="icon" onClick={() => setSelectedSite(null)}>
                  <X className="h-5 w-5" />
                </Button>
              </div>
              
              <div className="p-4">
                {heritageSites.find(site => site.id === selectedSite) && (
                  <div>
                    <img 
                      src={heritageSites.find(site => site.id === selectedSite)?.image} 
                      alt={heritageSites.find(site => site.id === selectedSite)?.name} 
                      className="w-full h-60 object-cover rounded-lg mb-4"
                    />
                    
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center">
                        <MapPin className="h-4 w-4 text-soul-maroon mr-1" />
                        <span className="text-gray-600">
                          {heritageSites.find(site => site.id === selectedSite)?.location}
                        </span>
                      </div>
                      <div className="flex items-center bg-gray-100 px-2 py-1 rounded-full">
                        <Star className="h-3 w-3 text-soul-gold fill-soul-gold mr-1" />
                        <span className="text-sm font-medium">
                          {heritageSites.find(site => site.id === selectedSite)?.rating}
                        </span>
                      </div>
                    </div>
                    
                    <p className="text-gray-700 mb-4">
                      {heritageSites.find(site => site.id === selectedSite)?.description}
                    </p>
                    
                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div>
                        <h4 className="font-medium text-sm text-gray-500 mb-1">Visit Duration</h4>
                        <p>{heritageSites.find(site => site.id === selectedSite)?.visitDuration}</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-sm text-gray-500 mb-1">Entry Fee</h4>
                        <p>{heritageSites.find(site => site.id === selectedSite)?.entryFee}</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-sm text-gray-500 mb-1">Best Time to Visit</h4>
                        <p>{heritageSites.find(site => site.id === selectedSite)?.bestTimeToVisit}</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-sm text-gray-500 mb-1">Opening Hours</h4>
                        <p>{heritageSites.find(site => site.id === selectedSite)?.openingHours}</p>
                      </div>
                    </div>
                    
                    <h4 className="font-medium mb-2">Local Tips</h4>
                    <ul className="list-disc pl-5 mb-4 text-gray-700 text-sm">
                      {heritageSites.find(site => site.id === selectedSite)?.localTips.map((tip, index) => (
                        <li key={index}>{tip}</li>
                      ))}
                    </ul>
                    
                    <div className="flex flex-col gap-2 mb-4">
                      <h4 className="font-medium mb-1">Visitor Reviews</h4>
                      {heritageSites.find(site => site.id === selectedSite)?.reviews.map((review, index) => (
                        <div key={index} className="bg-gray-50 p-2 rounded">
                          <div className="flex justify-between items-center">
                            <div className="flex items-center">
                              <User className="h-4 w-4 text-gray-400 mr-1" />
                              <span className="text-sm font-medium">{review.user}</span>
                            </div>
                            <div className="flex items-center">
                              <Star className="h-3 w-3 text-soul-gold fill-soul-gold" />
                              <span className="text-sm ml-1">{review.rating}</span>
                            </div>
                          </div>
                          <p className="text-sm text-gray-600 mt-1">{review.comment}</p>
                        </div>
                      ))}
                    </div>
                    
                    <div className="flex gap-2">
                      <Button className="flex-1 bg-soul-teal hover:bg-soul-teal/90">
                        View Full Details
                      </Button>
                      <Button variant="outline" className="flex-1">
                        View on Map
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </main>
      
      <Footer />
    </div>
  );
};

export default Explore;


import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { 
  Compass, 
  Globe, 
  Map, 
  Calendar, 
  User, 
  Menu, 
  X, 
  Search,
  Bookmark,
  LogOut
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/components/ui/use-toast";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    // Check current session
    const getSession = async () => {
      const { data } = await supabase.auth.getSession();
      setUser(data.session?.user || null);
      setLoading(false);
    };
    
    getSession();
    
    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        setUser(session?.user || null);
        setLoading(false);
      }
    );
    
    return () => subscription.unsubscribe();
  }, []);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const handleSignOut = async () => {
    try {
      await supabase.auth.signOut();
      toast({
        title: "Signed out",
        description: "You have been successfully signed out",
      });
      navigate("/");
    } catch (error: any) {
      toast({
        title: "Error",
        description: "Failed to sign out. Please try again.",
        variant: "destructive"
      });
    }
  };

  const navItems = [
    { name: "Explore", icon: <Compass className="h-5 w-5" />, href: "/explore" },
    { name: "Map", icon: <Map className="h-5 w-5" />, href: "/map" },
    { name: "Translate", icon: <Globe className="h-5 w-5" />, href: "/translate" },
    { name: "Events", icon: <Calendar className="h-5 w-5" />, href: "/events" },
    { name: "Saved", icon: <Bookmark className="h-5 w-5" />, href: "/saved" },
  ];

  return (
    <nav className="bg-white shadow-sm border-b z-50">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          <Link to="/" className="flex items-center space-x-2">
            <div className="relative w-10 h-10 bg-soul-orange rounded-full flex items-center justify-center">
              <span className="text-white font-display text-xl font-bold">S</span>
              <div className="absolute inset-0 bg-white rounded-full scale-[0.2] opacity-30 animate-pulse-gentle"></div>
            </div>
            <span className="text-xl font-display font-bold bg-gradient-to-r from-soul-orange to-soul-maroon bg-clip-text text-transparent">
              SoulYatra
            </span>
          </Link>

          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <Link
                key={item.name}
                to={item.href}
                className="flex items-center space-x-1 text-gray-700 hover:text-soul-orange transition-colors duration-200"
              >
                {item.icon}
                <span>{item.name}</span>
              </Link>
            ))}
          </div>

          <div className="hidden md:flex items-center space-x-4">
            <Button variant="ghost" size="icon" className="rounded-full">
              <Search className="h-5 w-5" />
            </Button>
            
            {!loading && (
              user ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="flex items-center space-x-1">
                      <User className="h-5 w-5" />
                      <span>{user.email?.split('@')[0] || 'User'}</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem className="cursor-pointer">Profile</DropdownMenuItem>
                    <DropdownMenuItem className="cursor-pointer">Settings</DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem 
                      className="cursor-pointer text-red-500 focus:text-red-500"
                      onClick={handleSignOut}
                    >
                      <LogOut className="h-4 w-4 mr-2" />
                      Sign Out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <Button 
                  variant="ghost" 
                  className="flex items-center space-x-1"
                  onClick={() => navigate("/auth")}
                >
                  <User className="h-5 w-5" />
                  <span>Sign In</span>
                </Button>
              )
            )}
          </div>

          <Button 
            variant="ghost" 
            size="icon" 
            className="md:hidden rounded-full" 
            onClick={toggleMenu}
          >
            {isOpen ? (
              <X className="h-6 w-6" />
            ) : (
              <Menu className="h-6 w-6" />
            )}
          </Button>
        </div>
      </div>

      {/* Mobile menu */}
      <div 
        className={cn(
          "fixed inset-0 bg-white z-50 pt-16 px-4 md:hidden transform transition-transform duration-300",
          isOpen ? "translate-x-0" : "translate-x-full"
        )}
      >
        <div className="space-y-6 py-6">
          {navItems.map((item) => (
            <Link
              key={item.name}
              to={item.href}
              className="flex items-center space-x-3 text-lg py-3 border-b"
              onClick={() => setIsOpen(false)}
            >
              {item.icon}
              <span>{item.name}</span>
            </Link>
          ))}
          
          {!loading && (
            user ? (
              <>
                <div className="flex items-center space-x-3 text-lg py-3 border-b">
                  <User className="h-5 w-5" />
                  <span>{user.email?.split('@')[0] || 'User'}</span>
                </div>
                <Button 
                  variant="destructive" 
                  className="w-full flex items-center justify-center space-x-2"
                  onClick={() => {
                    handleSignOut();
                    setIsOpen(false);
                  }}
                >
                  <LogOut className="h-5 w-5" />
                  <span>Sign Out</span>
                </Button>
              </>
            ) : (
              <Button 
                variant="default" 
                className="w-full flex items-center justify-center space-x-2"
                onClick={() => {
                  navigate("/auth");
                  setIsOpen(false);
                }}
              >
                <User className="h-5 w-5" />
                <span>Sign In</span>
              </Button>
            )
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navigation;

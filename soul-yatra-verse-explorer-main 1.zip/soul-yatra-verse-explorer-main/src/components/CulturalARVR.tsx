
import { useState } from "react";
import { Camera, Headset } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { culturalModels, ModelInfo } from "@/data/culturalModels";
import ModelListSidebar from "@/components/ModelListSidebar";
import ModelPreview from "@/components/ModelPreview";
import VRExperience from "@/components/VRExperience";

const CulturalARVR = () => {
  const [activeMode, setActiveMode] = useState<'ar' | 'vr'>('ar');
  const [models, setModels] = useState<ModelInfo[]>(culturalModels);
  const [activeModel, setActiveModel] = useState<ModelInfo>(models[0]);
  
  const navigateModels = (direction: 'prev' | 'next') => {
    const currentIndex = models.findIndex(m => m.id === activeModel.id);
    let newIndex;
    
    if (direction === 'prev') {
      newIndex = currentIndex === 0 ? models.length - 1 : currentIndex - 1;
    } else {
      newIndex = currentIndex === models.length - 1 ? 0 : currentIndex + 1;
    }
    
    setActiveModel(models[newIndex]);
  };
  
  const handleUpdateModel = (updatedModel: ModelInfo) => {
    const updatedModels = models.map(model => 
      model.id === updatedModel.id ? updatedModel : model
    );
    setModels(updatedModels);
    setActiveModel(updatedModel);
  };
  
  return (
    <div className="min-h-[600px] flex flex-col">
      <Tabs defaultValue="ar" onValueChange={(value) => setActiveMode(value as 'ar' | 'vr')} className="w-full">
        <div className="border-b px-4 py-2">
          <TabsList className="grid grid-cols-2">
            <TabsTrigger value="ar" className="flex items-center">
              <Camera className="h-4 w-4 mr-2" />
              AR Mode
            </TabsTrigger>
            <TabsTrigger value="vr" className="flex items-center">
              <Headset className="h-4 w-4 mr-2" />
              VR Experience
            </TabsTrigger>
          </TabsList>
        </div>
        
        <TabsContent value="ar" className="flex-grow flex flex-col mt-0">
          <div className="grid grid-cols-1 md:grid-cols-3 h-full">
            <ModelListSidebar 
              models={models} 
              activeModel={activeModel} 
              onSelectModel={setActiveModel}
            />
            <ModelPreview 
              activeModel={activeModel} 
              navigateModels={navigateModels}
              onUpdateModel={handleUpdateModel}
            />
          </div>
        </TabsContent>
        
        <TabsContent value="vr" className="flex-grow flex flex-col mt-0">
          <VRExperience />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default CulturalARVR;


import { Box, Layers, Download, Info, Camera, ArrowLeft, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ModelInfo } from "@/data/culturalModels";
import { useEffect, useState, useRef } from "react";
import { useToast } from "@/hooks/use-toast";

interface ModelPreviewProps {
  activeModel: ModelInfo;
  navigateModels: (direction: 'prev' | 'next') => void;
  onUpdateModel: (updatedModel: ModelInfo) => void;
}

const ModelPreview = ({ activeModel, navigateModels, onUpdateModel }: ModelPreviewProps) => {
  const [isLoading, setIsLoading] = useState(false);
  const [modelVisible, setModelVisible] = useState(false);
  const modelContainerRef = useRef<HTMLDivElement>(null);
  
  const { toast } = useToast();
  
  useEffect(() => {
    // Reset state when changing models
    setModelVisible(false);
    setIsLoading(true);
    
    const timer = setTimeout(() => {
      setIsLoading(false);
      setModelVisible(true);
    }, 1500);
    
    return () => clearTimeout(timer);
  }, [activeModel.id]);
  
  const handleDownload = () => {
    setIsLoading(true);
    
    setTimeout(() => {
      setIsLoading(false);
      
      toast({
        title: "Model Downloaded",
        description: `${activeModel.name} 3D model is now available for offline use.`,
        duration: 3000
      });
      
      // Update the model's offline status
      const updatedModel = {...activeModel, availableOffline: true};
      onUpdateModel(updatedModel);
    }, 2000);
  };
  
  return (
    <div className="md:col-span-2 flex flex-col">
      <div className="border-b p-4 flex justify-between items-center">
        <div>
          <h3 className="font-semibold">{activeModel.name}</h3>
          <div className="text-sm text-gray-500">{activeModel.location} • {activeModel.period}</div>
        </div>
        
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="sm"
            className="h-8"
            onClick={() => navigateModels('prev')}
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            className="h-8"
            onClick={() => navigateModels('next')}
          >
            <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      <div className="flex-grow relative p-4 flex flex-col">
        <div
          ref={modelContainerRef}
          className="flex-grow mb-4 bg-gray-100 rounded-lg flex items-center justify-center relative overflow-hidden"
        >
          {isLoading ? (
            <div className="flex flex-col items-center">
              <div className="h-12 w-12 border-4 border-soul-teal border-t-transparent rounded-full animate-spin mb-4"></div>
              <p className="text-gray-600">Loading 3D model...</p>
            </div>
          ) : (
            <>
              {modelVisible && (
                <div className="relative w-full h-full flex items-center justify-center">
                  <img 
                    src={activeModel.image} 
                    alt={activeModel.name} 
                    className="max-w-full max-h-full object-contain"
                  />
                  <div className="absolute inset-0 bg-gradient-to-b from-black/10 to-transparent pointer-events-none"></div>
                  <div className="absolute top-3 right-3 bg-black/50 text-white px-2 py-1 text-xs rounded backdrop-blur-sm">
                    AR Preview
                  </div>
                  
                  <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-2">
                    <Button variant="secondary" size="sm" className="backdrop-blur-sm bg-white/80">
                      <Box className="h-4 w-4 mr-1" />
                      Rotate
                    </Button>
                    <Button variant="secondary" size="sm" className="backdrop-blur-sm bg-white/80">
                      <Layers className="h-4 w-4 mr-1" />
                      Layers
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
        
        <div>
          <div className="flex items-start justify-between gap-4 mb-4">
            <p className="text-sm text-gray-700">{activeModel.description}</p>
            <Button 
              variant="outline" 
              size="icon" 
              className="flex-shrink-0"
            >
              <Info className="h-4 w-4" />
            </Button>
          </div>
          
          <div className="flex justify-between items-center">
            <div className="text-sm text-gray-500">
              {!activeModel.availableOffline && (
                <span>Download size: {activeModel.downloadSize}</span>
              )}
            </div>
            <div className="flex gap-2">
              {!activeModel.availableOffline && (
                <Button 
                  variant="outline" 
                  size="sm"
                  className="text-soul-teal border-soul-teal hover:bg-soul-teal/10"
                  onClick={handleDownload}
                >
                  <Download className="h-4 w-4 mr-1" />
                  Download for Offline
                </Button>
              )}
              <Button 
                size="sm"
                className="bg-soul-teal hover:bg-soul-teal/90"
              >
                <Camera className="h-4 w-4 mr-1" />
                Use in AR
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ModelPreview;

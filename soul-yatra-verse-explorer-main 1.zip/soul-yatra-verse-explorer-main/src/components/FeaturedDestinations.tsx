
import { useState } from "react";
import { Link } from "react-router-dom";
import { MapPin, Star, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
  CardDescription 
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

// Sample data - would come from an API in real implementation
const destinations = [
  {
    id: 1,
    name: "Taj Mahal",
    location: "Agra, India",
    image: "https://images.unsplash.com/photo-1548013146-72479768bada?auto=format&fit=crop&q=80&w=600&h=400",
    description: "A magnificent mausoleum built by Emperor Shah Jahan in memory of his wife Mumtaz Mahal.",
    category: "UNESCO World Heritage",
    rating: 4.9,
    distance: "5.2 km"
  },
  {
    id: 2,
    name: "The Great Wall",
    location: "Beijing, China",
    image: "https://images.unsplash.com/photo-1508804185872-d7badad00f7d?auto=format&fit=crop&q=80&w=600&h=400",
    description: "An ancient fortification built along the northern borders of China to protect against invasions.",
    category: "UNESCO World Heritage",
    rating: 4.8,
    distance: "120 km"
  },
  {
    id: 3,
    name: "Machu Picchu",
    location: "Cusco Region, Peru",
    image: "https://images.unsplash.com/photo-1526392060635-9d6019884377?auto=format&fit=crop&q=80&w=600&h=400",
    description: "An ancient Incan citadel set high in the Andes Mountains, featuring incredible ruins and views.",
    category: "UNESCO World Heritage",
    rating: 4.9,
    distance: "75 km"
  },
  {
    id: 4,
    name: "Petra",
    location: "Ma'an Governorate, Jordan",
    image: "https://images.unsplash.com/photo-1563177682-6684f9750f5a?auto=format&fit=crop&q=80&w=600&h=400",
    description: "A historic city famous for its rock-cut architecture and water conduit system.",
    category: "UNESCO World Heritage",
    rating: 4.7,
    distance: "50 km"
  }
];

const FeaturedDestinations = () => {
  const [activeCategory, setActiveCategory] = useState("All");
  
  const categories = ["All", "UNESCO World Heritage", "Historical", "Religious", "Natural"];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-10">
          <div>
            <h2 className="text-3xl font-bold mb-2">Featured Destinations</h2>
            <p className="text-gray-600">Explore iconic heritage sites from around the world</p>
          </div>
          
          <div className="mt-4 md:mt-0">
            <Button variant="outline" className="text-soul-teal border-soul-teal hover:bg-soul-teal/10">
              View All Destinations
            </Button>
          </div>
        </div>

        <div className="flex overflow-x-auto pb-4 mb-8 scrollbar-thin scrollbar-thumb-soul-orange scrollbar-track-gray-100">
          {categories.map((category) => (
            <Button
              key={category}
              variant={activeCategory === category ? "default" : "outline"}
              className={`mr-2 whitespace-nowrap ${
                activeCategory === category
                  ? "bg-soul-orange hover:bg-soul-orange/90"
                  : "text-gray-600 hover:text-soul-orange"
              }`}
              onClick={() => setActiveCategory(category)}
            >
              {category}
            </Button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {destinations.map((destination) => (
            <Card key={destination.id} className="cultural-card flex flex-col h-full">
              <div className="relative h-48 overflow-hidden">
                <img
                  src={destination.image}
                  alt={destination.name}
                  className="w-full h-full object-cover"
                />
                <Badge className="absolute top-3 right-3 bg-soul-maroon text-white">
                  {destination.category}
                </Badge>
              </div>
              
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <CardTitle className="text-xl">{destination.name}</CardTitle>
                  <div className="flex items-center">
                    <Star className="h-4 w-4 fill-soul-gold text-soul-gold mr-1" />
                    <span className="text-sm font-medium">{destination.rating}</span>
                  </div>
                </div>
                <CardDescription className="flex items-center text-sm text-gray-500">
                  <MapPin className="h-4 w-4 mr-1" />
                  {destination.location}
                </CardDescription>
              </CardHeader>
              
              <CardContent className="pb-4 flex-grow">
                <p className="text-gray-700 text-sm">{destination.description}</p>
              </CardContent>
              
              <CardFooter className="flex justify-between pt-2 border-t">
                <Button variant="ghost" size="sm" className="text-soul-teal">
                  <Info className="h-4 w-4 mr-1" />
                  Details
                </Button>
                <div className="text-sm text-gray-500 flex items-center">
                  <span>{destination.distance}</span>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedDestinations;


import { useState } from "react";
import { Send, User, Bot } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

const ChatbotPreview = () => {
  const [message, setMessage] = useState("");
  const [chatOpen, setChatOpen] = useState(false);
  
  // Sample conversation - in a real app, this would be dynamic
  const conversation = [
    {
      sender: "bot",
      text: "Hello! I'm your Cultural Assistant. I can help you learn about local customs, etiquette, and answer questions about cultural heritage sites. How can I assist you today?"
    },
    {
      sender: "user",
      text: "What should I know before visiting temples in India?"
    },
    {
      sender: "bot",
      text: "When visiting temples in India, it's customary to remove your shoes before entering. Dress modestly, covering shoulders and knees. Avoid touching sacred objects unless invited to. Photography may be restricted in some areas. It's also good to bring a small offering like flowers or fruits as a sign of respect."
    }
  ];

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim()) {
      // In a real app, this would add the message to the conversation
      // and trigger an API call to get a response
      console.log("Sending message:", message);
      setMessage("");
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-40">
      {/* Chat button */}
      <Button
        className={cn(
          "rounded-full w-16 h-16 shadow-lg flex items-center justify-center",
          !chatOpen ? "bg-soul-maroon hover:bg-soul-maroon/90" : "bg-gray-500 hover:bg-gray-600"
        )}
        onClick={() => setChatOpen(!chatOpen)}
      >
        {!chatOpen ? (
          <Bot className="h-7 w-7" />
        ) : (
          <User className="h-7 w-7" />
        )}
      </Button>

      {/* Chat window */}
      <div 
        className={cn(
          "absolute bottom-20 right-0 w-80 md:w-96 bg-white rounded-lg shadow-xl border border-gray-200 transition-all duration-300 transform origin-bottom-right",
          chatOpen ? "scale-100 opacity-100" : "scale-0 opacity-0"
        )}
      >
        <div className="bg-soul-maroon text-white p-4 rounded-t-lg">
          <h3 className="font-semibold">Cultural Assistant</h3>
          <p className="text-sm text-white/80">Get help with cultural etiquette & insights</p>
        </div>

        <div className="h-80 overflow-y-auto p-4 flex flex-col space-y-3">
          {conversation.map((item, index) => (
            <div 
              key={index} 
              className={cn(
                "max-w-[80%] rounded-lg p-3",
                item.sender === "user" 
                  ? "bg-soul-orange/10 text-gray-800 self-end" 
                  : "bg-gray-100 self-start"
              )}
            >
              {item.text}
            </div>
          ))}
        </div>

        <form onSubmit={handleSendMessage} className="p-3 border-t border-gray-200 flex">
          <Input
            type="text"
            placeholder="Ask about cultural etiquette..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className="rounded-l-md"
          />
          <Button 
            type="submit" 
            className="bg-soul-maroon hover:bg-soul-maroon/90 rounded-l-none"
          >
            <Send className="h-4 w-4" />
          </Button>
        </form>
      </div>
    </div>
  );
};

export default ChatbotPreview;

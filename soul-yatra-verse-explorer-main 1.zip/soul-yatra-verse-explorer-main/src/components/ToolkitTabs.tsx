
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Camera, Clock, User, Globe } from "lucide-react";
import CulturalARVR from "@/components/CulturalARVR";
import TimeTravelMode from "@/components/TimeTravelMode";
import UserProfile from "@/components/UserProfile";
import CulturalEtiquetteCoach from "@/components/CulturalEtiquetteCoach";

const ToolkitTabs = () => {
  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden mb-8">
      <Tabs defaultValue="arvr" className="w-full">
        <TabsList className="w-full justify-start bg-gray-50 p-0 rounded-none border-b">
          <TabsTrigger 
            value="arvr"
            className="data-[state=active]:bg-white rounded-b-none border-b-2 data-[state=active]:border-soul-teal border-transparent py-3 px-6"
          >
            <Camera className="h-4 w-4 mr-2" />
            AR/VR Experience
          </TabsTrigger>
          <TabsTrigger 
            value="timetravel"
            className="data-[state=active]:bg-white rounded-b-none border-b-2 data-[state=active]:border-soul-orange border-transparent py-3 px-6"
          >
            <Clock className="h-4 w-4 mr-2" />
            Time Travel
          </TabsTrigger>
          <TabsTrigger 
            value="etiquette"
            className="data-[state=active]:bg-white rounded-b-none border-b-2 data-[state=active]:border-soul-maroon border-transparent py-3 px-6"
          >
            <Globe className="h-4 w-4 mr-2" />
            Cultural Etiquette
          </TabsTrigger>
          <TabsTrigger 
            value="profile"
            className="data-[state=active]:bg-white rounded-b-none border-b-2 data-[state=active]:border-soul-gold border-transparent py-3 px-6"
          >
            <User className="h-4 w-4 mr-2" />
            Your Journey
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="arvr" className="mt-0">
          <CulturalARVR />
        </TabsContent>
        
        <TabsContent value="timetravel" className="mt-0">
          <TimeTravelMode />
        </TabsContent>
        
        <TabsContent value="etiquette" className="mt-0">
          <CulturalEtiquetteCoach />
        </TabsContent>
        
        <TabsContent value="profile" className="mt-0">
          <UserProfile />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ToolkitTabs;

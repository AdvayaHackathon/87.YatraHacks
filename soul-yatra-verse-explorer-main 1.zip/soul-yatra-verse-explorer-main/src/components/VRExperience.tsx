
import { Headset, Box } from "lucide-react";
import { Button } from "@/components/ui/button";

const VRExperience = () => {
  return (
    <div className="p-4 text-center flex items-center flex-col justify-center flex-grow">
      <Headset className="h-16 w-16 text-soul-maroon mb-4" />
      <h3 className="text-xl font-semibold mb-2">VR Experience</h3>
      <p className="text-gray-600 max-w-md mb-6">
        Immerse yourself in a 360° virtual reality experience of heritage sites. 
        Connect your VR headset or use mobile VR mode.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-md">
        <Button variant="outline" className="border-soul-maroon text-soul-maroon hover:bg-soul-maroon/10">
          <Headset className="h-4 w-4 mr-2" />
          Connect VR Headset
        </Button>
        <Button className="bg-soul-maroon hover:bg-soul-maroon/90">
          <Box className="h-4 w-4 mr-2" />
          Start Mobile VR
        </Button>
      </div>
    </div>
  );
};

export default VRExperience;

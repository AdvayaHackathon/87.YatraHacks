
import { Button } from "@/components/ui/button";
import { Wifi, WifiOff } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ToolkitHeaderProps {
  isOfflineMode: boolean;
  toggleOfflineMode: () => void;
}

const ToolkitHeader = ({ isOfflineMode, toggleOfflineMode }: ToolkitHeaderProps) => {
  return (
    <div className="flex justify-between items-center mb-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Cultural Toolkit</h1>
        <p className="text-gray-600">
          Explore heritage through immersive technologies, track your cultural journey, and learn local customs
        </p>
      </div>
      
      <Button 
        variant="outline" 
        className={`flex items-center ${isOfflineMode ? 'border-soul-orange text-soul-orange' : 'border-gray-200'}`}
        onClick={toggleOfflineMode}
      >
        {isOfflineMode ? (
          <>
            <WifiOff className="h-4 w-4 mr-2" />
            Offline Mode
          </>
        ) : (
          <>
            <Wifi className="h-4 w-4 mr-2" />
            Online Mode
          </>
        )}
      </Button>
    </div>
  );
};

export default ToolkitHeader;


import { useState, useRef, useEffect } from "react";
import { Clock, Calendar, ArrowLeft, ArrowRight, Info, Camera, Download, Maximize2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

interface HistoricalPeriod {
  year: number;
  name: string;
  description: string;
  image: string;
  events: string[];
}

interface HistoricalSite {
  id: number;
  name: string;
  location: string;
  periods: HistoricalPeriod[];
}

const historicalSites: HistoricalSite[] = [
  {
    id: 1,
    name: "Taj Mahal",
    location: "Agra, India",
    periods: [
      {
        year: 1632,
        name: "Construction Begins",
        description: "Emperor Shah Jahan begins construction of the Taj Mahal as a mausoleum for his beloved wife Mumtaz Mahal.",
        image: "https://i.imgur.com/7FYRZRn.jpg",
        events: [
          "Construction was led by architect Ustad Ahmad Lahori",
          "Over 20,000 artisans and craftsmen were employed",
          "Precious and semi-precious stones were sourced from across Asia"
        ]
      },
      {
        year: 1648,
        name: "Completion",
        description: "The main mausoleum is completed after 16 years of construction.",
        image: "https://i.imgur.com/HJF90Pb.jpg",
        events: [
          "Gardens and surrounding buildings were still under construction",
          "Shah Jahan's grief for Mumtaz remained profound",
          "The total cost was approximately 32 million rupees"
        ]
      },
      {
        year: 1830,
        name: "British Colonial Era",
        description: "During British rule, the Taj Mahal's gardens were redesigned in a more European style.",
        image: "https://i.imgur.com/WKLB7Ms.jpg",
        events: [
          "Original Mughal gardens were replaced with lawns",
          "The complex suffered neglect and deterioration",
          "Lord Curzon ordered a major restoration project in the early 1900s"
        ]
      },
      {
        year: 1947,
        name: "Post-Independence",
        description: "After India's independence, the Taj Mahal becomes a symbol of national pride and attracts global tourism.",
        image: "https://i.imgur.com/2N5teQA.jpg",
        events: [
          "Restoration efforts undertaken by the Indian government",
          "UNESCO World Heritage Site designation in 1983",
          "Increased focus on protection from environmental threats"
        ]
      },
      {
        year: 2023,
        name: "Present Day",
        description: "The Taj Mahal today faces challenges from pollution, tourism pressure, and environmental degradation.",
        image: "https://images.unsplash.com/photo-1564507592333-c60657eea523?auto=format&fit=crop&q=80&w=600&h=400",
        events: [
          "Advanced conservation techniques being employed",
          "Visitor number restrictions implemented",
          "Air purification systems installed around the complex"
        ]
      }
    ]
  },
  {
    id: 2,
    name: "Qutub Minar",
    location: "Delhi, India",
    periods: [
      {
        year: 1193,
        name: "Construction Begins",
        description: "Qutb-ud-din Aibak begins construction of the Qutub Minar to celebrate Muslim dominance in Delhi.",
        image: "https://i.imgur.com/Q4WYdkU.jpg",
        events: [
          "Built on the ruins of the Lal Kot, the red citadel in Delhi",
          "Initially only the first story was constructed",
          "Used sandstone and marble in construction"
        ]
      },
      {
        year: 1220,
        name: "Expansion",
        description: "Iltutmish, Aibak's successor, adds three more stories to the minaret.",
        image: "https://i.imgur.com/XYTQgVD.jpg",
        events: [
          "Intricate carvings and inscriptions from the Quran were added",
          "The architectural style evolved with each new addition",
          "Became the tallest minaret in the world at the time"
        ]
      },
      {
        year: 1368,
        name: "Repairs",
        description: "Firoz Shah Tughlaq carries out repairs and adds a fifth story to the minaret.",
        image: "https://i.imgur.com/XSBTncC.jpg",
        events: [
          "The fifth story was constructed of white marble",
          "Distinctive architectural style different from lower stories",
          "Surrounding complex expanded with additional structures"
        ]
      },
      {
        year: 1800,
        name: "Colonial Period",
        description: "During British rule, the Qutub complex undergoes various restoration efforts.",
        image: "https://i.imgur.com/Nb4xgsV.jpg",
        events: [
          "Major earthquake damage in 1803 was repaired",
          "British officials documented and studied the site",
          "Became a popular tourist destination for European visitors"
        ]
      },
      {
        year: 2023,
        name: "Present Day",
        description: "Today the Qutub Minar is one of Delhi's most important historical sites and a UNESCO World Heritage monument.",
        image: "https://images.unsplash.com/photo-1626379953822-baec19c3accd?auto=format&fit=crop&q=80&w=600&h=400",
        events: [
          "Advanced conservation techniques employed",
          "Digital documentation for preservation",
          "One of India's most visited historical sites"
        ]
      }
    ]
  }
];

const TimeTravelMode = () => {
  const [selectedSite, setSelectedSite] = useState<HistoricalSite>(historicalSites[0]);
  const [currentPeriodIndex, setCurrentPeriodIndex] = useState(0);
  const [sliderValue, setSliderValue] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const imageRef = useRef<HTMLImageElement>(null);
  
  const { toast } = useToast();
  
  const currentPeriod = selectedSite.periods[currentPeriodIndex];
  const years = selectedSite.periods.map(period => period.year);
  const minYear = Math.min(...years);
  const maxYear = Math.max(...years);
  const yearRange = maxYear - minYear;
  
  // Handle year slider change
  useEffect(() => {
    // Calculate which period this year corresponds to
    const year = minYear + Math.round((yearRange * sliderValue) / 100);
    
    // Find the closest period
    let closestIndex = 0;
    let closestDistance = Math.abs(year - selectedSite.periods[0].year);
    
    for (let i = 1; i < selectedSite.periods.length; i++) {
      const distance = Math.abs(year - selectedSite.periods[i].year);
      if (distance < closestDistance) {
        closestDistance = distance;
        closestIndex = i;
      }
    }
    
    if (closestIndex !== currentPeriodIndex) {
      setIsTransitioning(true);
      setTimeout(() => {
        setCurrentPeriodIndex(closestIndex);
        setIsTransitioning(false);
      }, 500);
    }
  }, [sliderValue, selectedSite.periods, currentPeriodIndex, minYear, yearRange]);
  
  // Update slider when directly navigating between periods
  useEffect(() => {
    const periodYear = currentPeriod.year;
    const percentage = ((periodYear - minYear) / yearRange) * 100;
    setSliderValue(percentage);
  }, [currentPeriodIndex, currentPeriod.year, minYear, yearRange]);
  
  const handlePrevPeriod = () => {
    if (currentPeriodIndex > 0) {
      setIsTransitioning(true);
      setTimeout(() => {
        setCurrentPeriodIndex(currentPeriodIndex - 1);
        setIsTransitioning(false);
      }, 500);
    }
  };
  
  const handleNextPeriod = () => {
    if (currentPeriodIndex < selectedSite.periods.length - 1) {
      setIsTransitioning(true);
      setTimeout(() => {
        setCurrentPeriodIndex(currentPeriodIndex + 1);
        setIsTransitioning(false);
      }, 500);
    }
  };
  
  const handleSiteChange = (siteId: number) => {
    const site = historicalSites.find(s => s.id === siteId);
    if (site) {
      setSelectedSite(site);
      setCurrentPeriodIndex(0);
    }
  };
  
  const handleScreenshot = () => {
    toast({
      title: "Screenshot Captured",
      description: `Time travel image of ${selectedSite.name} from ${currentPeriod.year} saved to your gallery.`,
      duration: 3000
    });
  };
  
  return (
    <div className="min-h-[600px] flex flex-col">
      <div className="border-b px-4 py-2 flex justify-between items-center">
        <h2 className="font-semibold flex items-center">
          <Clock className="h-5 w-5 mr-2 text-soul-orange" />
          Time Travel Mode
        </h2>
        
        <div className="flex gap-2">
          <select 
            className="text-sm border rounded px-2 py-1"
            value={selectedSite.id}
            onChange={(e) => handleSiteChange(Number(e.target.value))}
          >
            {historicalSites.map(site => (
              <option key={site.id} value={site.id}>
                {site.name}
              </option>
            ))}
          </select>
        </div>
      </div>
      
      <div className="flex-grow flex flex-col md:flex-row">
        <div className="md:w-3/4 relative">
          {/* Time travel image viewer */}
          <div className="relative h-[400px] md:h-full overflow-hidden">
            <img 
              ref={imageRef}
              src={currentPeriod.image} 
              alt={`${selectedSite.name} in ${currentPeriod.year}`} 
              className={`w-full h-full object-cover transition-opacity duration-500 ${isTransitioning ? 'opacity-0' : 'opacity-100'}`}
            />
            
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent pointer-events-none"></div>
            
            <div className="absolute top-3 right-3 flex gap-2">
              <Button 
                variant="secondary" 
                size="icon" 
                className="bg-black/30 hover:bg-black/50 backdrop-blur-sm text-white"
                onClick={handleScreenshot}
              >
                <Camera className="h-4 w-4" />
              </Button>
              <Button 
                variant="secondary" 
                size="icon" 
                className="bg-black/30 hover:bg-black/50 backdrop-blur-sm text-white"
              >
                <Maximize2 className="h-4 w-4" />
              </Button>
            </div>
            
            <div className="absolute bottom-4 left-4">
              <Badge className="bg-black/50 backdrop-blur-sm text-white border-none">
                {currentPeriod.year}
              </Badge>
              <h3 className="text-white text-xl font-bold mt-1 drop-shadow-md">
                {currentPeriod.name}
              </h3>
              <p className="text-white/90 text-sm max-w-md drop-shadow-md">
                {currentPeriod.description}
              </p>
            </div>
          </div>
          
          {/* Time slider */}
          <div className="absolute bottom-0 inset-x-0 bg-black/70 backdrop-blur-sm text-white p-4">
            <div className="flex justify-between items-center mb-2 text-xs">
              <span>{minYear}</span>
              <span>Time Period</span>
              <span>{maxYear}</span>
            </div>
            
            <div className="flex items-center gap-4">
              <Button 
                variant="ghost" 
                size="icon" 
                className="text-white h-8 w-8" 
                onClick={handlePrevPeriod}
                disabled={currentPeriodIndex === 0}
              >
                <ArrowLeft className="h-4 w-4" />
              </Button>
              
              <div className="flex-grow">
                <Slider 
                  value={[sliderValue]}
                  min={0}
                  max={100}
                  step={1}
                  onValueChange={(values) => setSliderValue(values[0])}
                  className="time-slider"
                />
                
                <div className="flex justify-between mt-2">
                  {selectedSite.periods.map((period, index) => (
                    <div 
                      key={period.year}
                      className={`cursor-pointer transition-all duration-200 ${index === currentPeriodIndex ? 'scale-110' : 'opacity-70'}`}
                      style={{ 
                        position: 'absolute',
                        left: `${((period.year - minYear) / yearRange) * 100}%`,
                        transform: 'translateX(-50%)'
                      }}
                      onClick={() => setCurrentPeriodIndex(index)}
                    >
                      <div 
                        className={`h-2 w-2 rounded-full mb-1 mx-auto ${index === currentPeriodIndex ? 'bg-soul-orange' : 'bg-white/70'}`}
                      ></div>
                      <span className="text-[10px] whitespace-nowrap">{period.year}</span>
                    </div>
                  ))}
                </div>
              </div>
              
              <Button 
                variant="ghost" 
                size="icon" 
                className="text-white h-8 w-8" 
                onClick={handleNextPeriod}
                disabled={currentPeriodIndex === selectedSite.periods.length - 1}
              >
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
        
        <div className="md:w-1/4 border-l p-4">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-semibold">{currentPeriod.name}</h3>
            <Badge className="bg-soul-orange">{currentPeriod.year}</Badge>
          </div>
          
          <div className="mb-6">
            <h4 className="flex items-center text-sm font-medium mb-2 text-gray-700">
              <Calendar className="h-4 w-4 mr-1 text-soul-maroon" />
              Historical Events
            </h4>
            <ul className="space-y-2">
              {currentPeriod.events.map((event, index) => (
                <li key={index} className="flex items-start text-sm">
                  <div className="h-4 w-4 rounded-full bg-soul-orange/20 text-soul-orange flex items-center justify-center flex-shrink-0 mt-0.5 mr-2">
                    <span className="text-[10px] font-bold">{index + 1}</span>
                  </div>
                  <span className="text-gray-700">{event}</span>
                </li>
              ))}
            </ul>
          </div>
          
          <div className="mb-6">
            <h4 className="flex items-center text-sm font-medium mb-2 text-gray-700">
              <Info className="h-4 w-4 mr-1 text-soul-maroon" />
              Compare With
            </h4>
            <div className="grid grid-cols-2 gap-2">
              {selectedSite.periods
                .filter((_, i) => i !== currentPeriodIndex)
                .slice(0, 4)
                .map((period) => (
                  <div 
                    key={period.year} 
                    className="border rounded-md p-1 cursor-pointer hover:bg-gray-50 transition-colors"
                    onClick={() => {
                      setIsTransitioning(true);
                      setTimeout(() => {
                        setCurrentPeriodIndex(selectedSite.periods.findIndex(p => p.year === period.year));
                        setIsTransitioning(false);
                      }, 500);
                    }}
                  >
                    <div className="text-xs font-medium">{period.year}</div>
                    <div className="text-xs text-gray-500 truncate">{period.name}</div>
                  </div>
                ))}
            </div>
          </div>
          
          <Button 
            className="w-full bg-soul-orange hover:bg-soul-orange/90"
            onClick={() => {
              toast({
                title: "Time Travel Journey Saved",
                description: `Your exploration of ${selectedSite.name} through time has been saved to your collection.`,
                duration: 3000
              });
            }}
          >
            <Download className="h-4 w-4 mr-2" />
            Save Time Journey
          </Button>
        </div>
      </div>
    </div>
  );
};

export default TimeTravelMode;

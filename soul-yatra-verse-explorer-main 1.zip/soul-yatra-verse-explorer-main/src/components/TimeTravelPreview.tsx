
import { useState } from "react";
import { Clock, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const TimeTravelPreview = () => {
  const [timelineYear, setTimelineYear] = useState(1950);
  
  // Sample historical data - in a real app this would come from an API
  const timelineDates = [1850, 1900, 1950, 2000, 2023];
  
  const handleTimeChange = (year: number) => {
    setTimelineYear(year);
  };

  return (
    <section className="py-16 relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute inset-0 pattern-overlay"></div>
      <div className="absolute top-20 left-10 w-32 h-32 bg-soul-teal/10 rounded-full blur-xl"></div>
      <div className="absolute bottom-20 right-10 w-48 h-48 bg-soul-orange/10 rounded-full blur-xl"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center justify-center rounded-full bg-soul-orange/10 p-2 mb-4">
            <Clock className="h-6 w-6 text-soul-orange" />
          </div>
          <h2 className="text-3xl font-bold mb-3">Time Travel Mode</h2>
          <p className="text-gray-600">
            Experience heritage sites through different time periods. See how monuments and 
            cities evolved throughout history.
          </p>
        </div>
        
        <div className="bg-white rounded-lg shadow-xl overflow-hidden max-w-5xl mx-auto transform transition-all hover:scale-[1.02] duration-300">
          <div className="grid grid-cols-1 md:grid-cols-2">
            <div className="p-6 md:p-8 flex flex-col justify-between">
              <div>
                <h3 className="text-2xl font-bold mb-4">Taj Mahal Through Time</h3>
                <p className="text-gray-600 mb-6">
                  Witness the evolution of the Taj Mahal and its surroundings from its 
                  construction in 1643 to present day.
                </p>
                
                <div className="space-y-3 mb-8">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-soul-maroon"></div>
                    <span className="text-gray-700">Original Construction (1643)</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-soul-gold"></div>
                    <span className="text-gray-700">British Colonial Era (1857)</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-soul-teal"></div>
                    <span className="text-gray-700">Post-Independence Restoration (1950s)</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-soul-orange"></div>
                    <span className="text-gray-700">Modern Day UNESCO Site (Present)</span>
                  </div>
                </div>
              </div>
              
              <div>
                <div className="mb-4">
                  <p className="text-sm text-gray-500 mb-2">Select time period:</p>
                  <div className="flex justify-between items-center">
                    {timelineDates.map((year) => (
                      <Button 
                        key={year}
                        variant={timelineYear === year ? "default" : "outline"}
                        size="sm"
                        className={timelineYear === year ? "bg-soul-maroon hover:bg-soul-maroon/90" : ""}
                        onClick={() => handleTimeChange(year)}
                      >
                        {year}
                      </Button>
                    ))}
                  </div>
                </div>
                
                <Button className="w-full bg-soul-orange hover:bg-soul-orange/90">
                  Experience Time Travel Mode
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </div>
            
            <div className="relative h-[300px] md:h-auto bg-gray-100">
              <img 
                src={`https://images.unsplash.com/photo-1564507592333-c60657eea523?auto=format&fit=crop&q=80&w=600&h=800`} 
                alt="Taj Mahal" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent flex items-end">
                <div className="p-6 text-white">
                  <span className="font-medium">{timelineYear}</span>
                  <h4 className="text-lg font-semibold">
                    {timelineYear < 1900 ? "Historical Era" : 
                     timelineYear < 1950 ? "Early Modern Period" : 
                     timelineYear < 2000 ? "Post-Independence Era" : "Contemporary Period"}
                  </h4>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TimeTravelPreview;

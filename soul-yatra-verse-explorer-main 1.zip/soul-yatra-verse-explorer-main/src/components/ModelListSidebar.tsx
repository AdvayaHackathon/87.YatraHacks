
import { ModelInfo } from "@/data/culturalModels";
import { Badge } from "@/components/ui/badge";

interface ModelListSidebarProps {
  models: ModelInfo[];
  activeModel: ModelInfo;
  onSelectModel: (model: ModelInfo) => void;
}

const ModelListSidebar = ({ models, activeModel, onSelectModel }: ModelListSidebarProps) => {
  return (
    <div className="p-4 border-r">
      <h3 className="font-semibold mb-4">3D Cultural Models</h3>
      
      <div className="space-y-4">
        {models.map(model => (
          <div 
            key={model.id}
            className={`border rounded-lg overflow-hidden cursor-pointer transition-shadow hover:shadow-md ${activeModel.id === model.id ? 'ring-2 ring-soul-teal' : ''}`}
            onClick={() => onSelectModel(model)}
          >
            <div className="h-24 overflow-hidden">
              <img 
                src={model.image} 
                alt={model.name} 
                className="w-full h-full object-cover"
              />
            </div>
            <div className="p-2">
              <h4 className="font-medium">{model.name}</h4>
              <div className="flex justify-between items-center text-xs text-gray-500">
                <span>{model.period}</span>
                {model.availableOffline && (
                  <Badge variant="outline" className="h-5 text-[10px] bg-green-50 border-green-200 text-green-600">
                    Available Offline
                  </Badge>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ModelListSidebar;

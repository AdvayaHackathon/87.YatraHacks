
import { useState } from "react";
import { 
  User, 
  Medal, 
  Map, 
  Camera, 
  Clock, 
  Heart, 
  Calendar, 
  ChevronRight, 
  Star, 
  Award, 
  Trophy, 
  CheckCircle 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const achievements = [
  {
    id: 1,
    name: "Heritage Explorer",
    description: "Visit 5 UNESCO World Heritage Sites",
    progress: 3,
    total: 5,
    icon: <Map className="h-5 w-5 text-soul-teal" />,
    completed: false,
    points: 500
  },
  {
    id: 2,
    name: "Culture Connoisseur",
    description: "Attend 3 cultural events or festivals",
    progress: 2,
    total: 3,
    icon: <Calendar className="h-5 w-5 text-soul-orange" />,
    completed: false,
    points: 300
  },
  {
    id: 3,
    name: "Time Traveler",
    description: "Use the Time Travel mode 10 times",
    progress: 10,
    total: 10,
    icon: <Clock className="h-5 w-5 text-soul-maroon" />,
    completed: true,
    points: 250
  },
  {
    id: 4,
    name: "Tradition Keeper",
    description: "Learn about 5 different cultural traditions",
    progress: 4,
    total: 5,
    icon: <Award className="h-5 w-5 text-soul-gold" />,
    completed: false,
    points: 200
  }
];

const badges = [
  {
    id: 1,
    name: "Taj Mahal Explorer",
    image: "https://images.unsplash.com/photo-1564507592333-c60657eea523?auto=format&fit=crop&q=80&w=80&h=80",
    date: "Oct 15, 2023",
    unlocked: true
  },
  {
    id: 2,
    name: "Festival Enthusiast",
    image: "https://images.unsplash.com/photo-1604845029162-bc4d3716b764?auto=format&fit=crop&q=80&w=80&h=80",
    date: "Sep 2, 2023",
    unlocked: true
  },
  {
    id: 3,
    name: "Culinary Adventurer",
    image: "https://images.unsplash.com/photo-1535568824865-a851eda1322b?auto=format&fit=crop&q=80&w=80&h=80",
    date: "Aug 12, 2023",
    unlocked: true
  },
  {
    id: 4,
    name: "Architecture Aficionado",
    image: "https://images.unsplash.com/photo-1572386941853-16a9a4202fdb?auto=format&fit=crop&q=80&w=80&h=80",
    date: "Jul 20, 2023",
    unlocked: false
  }
];

const visitedSites = [
  {
    id: 1,
    name: "Taj Mahal",
    location: "Agra, India",
    date: "Oct 15, 2023",
    image: "https://images.unsplash.com/photo-1564507592333-c60657eea523?auto=format&fit=crop&q=80&w=150&h=100",
    rating: 5
  },
  {
    id: 2,
    name: "Amer Fort",
    location: "Jaipur, India",
    date: "Oct 10, 2023",
    image: "https://images.unsplash.com/photo-1598874399428-ad0dddda7eb7?auto=format&fit=crop&q=80&w=150&h=100",
    rating: 4
  },
  {
    id: 3,
    name: "Hawa Mahal",
    location: "Jaipur, India",
    date: "Oct 9, 2023",
    image: "https://images.unsplash.com/photo-1599661046253-10c935a6855d?auto=format&fit=crop&q=80&w=150&h=100",
    rating: 4
  }
];

const upcomingEvents = [
  {
    id: 1,
    name: "Diwali Festival",
    location: "Various locations, India",
    date: "Nov 12, 2023",
    image: "https://images.unsplash.com/photo-1605021304650-80a6b2ddc862?auto=format&fit=crop&q=80&w=150&h=100"
  },
  {
    id: 2,
    name: "Pushkar Camel Fair",
    location: "Pushkar, Rajasthan",
    date: "Nov 20, 2023",
    image: "https://images.unsplash.com/photo-1516398810565-0cb4310bb8ea?auto=format&fit=crop&q=80&w=150&h=100"
  }
];

const UserProfile = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(true);
  
  const totalPoints = achievements.reduce((sum, achievement) => {
    return sum + (achievement.completed ? achievement.points : Math.floor((achievement.progress / achievement.total) * achievement.points));
  }, 0);
  
  const completedAchievements = achievements.filter(a => a.completed).length;
  const level = Math.floor(totalPoints / 1000) + 1;
  const pointsToNextLevel = 1000 - (totalPoints % 1000);
  const progressToNextLevel = ((1000 - pointsToNextLevel) / 1000) * 100;
  
  if (!isLoggedIn) {
    return (
      <div className="min-h-[600px] flex flex-col items-center justify-center p-4">
        <div className="text-center max-w-md">
          <User className="h-12 w-12 mx-auto mb-4 text-soul-maroon" />
          <h2 className="text-2xl font-bold mb-2">Sign In to SoulYatra</h2>
          <p className="text-gray-600 mb-6">
            Track your cultural journey, earn points for visiting heritage sites,
            and unlock special badges and achievements.
          </p>
          <div className="space-y-3">
            <Button className="w-full bg-soul-maroon hover:bg-soul-maroon/90">
              Sign In
            </Button>
            <Button variant="outline" className="w-full">
              Create Account
            </Button>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="flex flex-col min-h-[600px]">
      <div className="bg-gradient-to-r from-soul-maroon to-soul-orange p-6 text-white">
        <div className="flex items-center gap-4">
          <Avatar className="h-16 w-16 border-2 border-white">
            <AvatarImage src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150&h=150" />
            <AvatarFallback>VS</AvatarFallback>
          </Avatar>
          
          <div className="flex-grow">
            <h2 className="text-xl font-bold">Vidya Sharma</h2>
            <div className="flex items-center text-white/90 text-sm mb-2">
              <Badge className="bg-white/20 hover:bg-white/30 text-white mr-2">
                Level {level}
              </Badge>
              <Medal className="h-4 w-4 mr-1" />
              <span>{totalPoints} points</span>
            </div>
            <div className="w-full flex items-center gap-2">
              <Progress value={progressToNextLevel} className="h-2 bg-white/30" />
              <span className="text-xs whitespace-nowrap">{pointsToNextLevel} pts to level {level + 1}</span>
            </div>
          </div>
        </div>
      </div>
      
      <Tabs defaultValue="achievements" className="flex-grow">
        <div className="border-b">
          <TabsList className="w-full justify-start border-0 bg-transparent pt-0">
            <TabsTrigger value="achievements" className="data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-soul-orange rounded-none data-[state=active]:shadow-none">
              Achievements
            </TabsTrigger>
            <TabsTrigger value="badges" className="data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-soul-orange rounded-none data-[state=active]:shadow-none">
              Badges
            </TabsTrigger>
            <TabsTrigger value="history" className="data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-soul-orange rounded-none data-[state=active]:shadow-none">
              Travel History
            </TabsTrigger>
            <TabsTrigger value="upcoming" className="data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-soul-orange rounded-none data-[state=active]:shadow-none">
              Upcoming
            </TabsTrigger>
          </TabsList>
        </div>
        
        <TabsContent value="achievements" className="p-4 mt-0">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {achievements.map((achievement) => (
              <Card key={achievement.id} className="overflow-hidden">
                <CardContent className="p-0">
                  <div className="flex p-4">
                    <div className={`rounded-full p-3 mr-3 ${achievement.completed ? 'bg-green-100' : 'bg-gray-100'}`}>
                      {achievement.icon}
                    </div>
                    <div className="flex-grow">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-semibold">{achievement.name}</h3>
                          <p className="text-sm text-gray-600 mb-2">{achievement.description}</p>
                        </div>
                        {achievement.completed && (
                          <CheckCircle className="h-5 w-5 text-green-500" />
                        )}
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 flex-grow">
                          <Progress 
                            value={(achievement.progress / achievement.total) * 100} 
                            className="h-2"
                          />
                          <span className="text-xs text-gray-500 whitespace-nowrap">
                            {achievement.progress}/{achievement.total}
                          </span>
                        </div>
                        <Badge className="bg-soul-gold ml-2">
                          {achievement.points} pts
                        </Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <div className="mt-4 p-4 bg-gray-50 rounded-lg">
            <div className="flex justify-between items-center mb-3">
              <h3 className="font-semibold">Achievement Stats</h3>
              <Button variant="ghost" size="sm" className="h-8 text-xs">
                View All
              </Button>
            </div>
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="bg-white p-3 rounded-lg">
                <div className="text-2xl font-bold text-soul-maroon">{completedAchievements}</div>
                <div className="text-xs text-gray-500">Completed</div>
              </div>
              <div className="bg-white p-3 rounded-lg">
                <div className="text-2xl font-bold text-soul-orange">{achievements.length}</div>
                <div className="text-xs text-gray-500">Total</div>
              </div>
              <div className="bg-white p-3 rounded-lg">
                <div className="text-2xl font-bold text-soul-teal">{totalPoints}</div>
                <div className="text-xs text-gray-500">Points</div>
              </div>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="badges" className="p-4 mt-0">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {badges.map((badge) => (
              <div 
                key={badge.id} 
                className={`relative rounded-lg p-4 text-center border ${badge.unlocked ? 'bg-white' : 'bg-gray-50 opacity-70'}`}
              >
                <div className="relative inline-block">
                  <div className="w-16 h-16 rounded-full overflow-hidden mx-auto mb-2">
                    <img 
                      src={badge.image} 
                      alt={badge.name} 
                      className={`w-full h-full object-cover ${!badge.unlocked && 'filter grayscale'}`}
                    />
                  </div>
                  {badge.unlocked && (
                    <div className="absolute -bottom-1 -right-1 bg-green-500 text-white rounded-full p-1">
                      <CheckCircle className="h-3 w-3" />
                    </div>
                  )}
                </div>
                <h3 className="font-medium text-sm mb-1">{badge.name}</h3>
                {badge.unlocked ? (
                  <p className="text-xs text-gray-500">Unlocked: {badge.date}</p>
                ) : (
                  <p className="text-xs text-gray-500">Locked</p>
                )}
              </div>
            ))}
          </div>
          
          <div className="mt-6">
            <h3 className="font-semibold mb-3">Trophy Case</h3>
            <div className="bg-gray-50 border rounded-lg p-4 flex items-center justify-center">
              <div className="text-center">
                <Trophy className="h-10 w-10 text-soul-gold mx-auto mb-2" />
                <h4 className="font-medium mb-1">Level 5 Trophy</h4>
                <p className="text-sm text-gray-600">Reach Level 5 to unlock this trophy</p>
                <div className="flex items-center justify-center mt-2">
                  <Progress value={75} className="h-2 w-40" />
                  <span className="text-xs text-gray-500 ml-2">75%</span>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="history" className="p-4 mt-0">
          <div className="space-y-4">
            {visitedSites.map((site) => (
              <div key={site.id} className="flex border rounded-lg overflow-hidden shadow-sm">
                <div className="w-[150px] h-[100px]">
                  <img 
                    src={site.image} 
                    alt={site.name} 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-grow p-4">
                  <div className="flex justify-between">
                    <div>
                      <h3 className="font-semibold">{site.name}</h3>
                      <div className="flex items-center text-sm text-gray-500 mb-1">
                        <Map className="h-3 w-3 mr-1" />
                        <span>{site.location}</span>
                      </div>
                      <div className="text-xs text-gray-500">
                        Visited: {site.date}
                      </div>
                    </div>
                    <div className="flex flex-col items-end">
                      <div className="flex items-center mb-2">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star 
                            key={i} 
                            className={`h-4 w-4 ${i < site.rating ? 'text-soul-gold fill-soul-gold' : 'text-gray-300'}`} 
                          />
                        ))}
                      </div>
                      <Button variant="ghost" size="sm" className="h-7 px-2 text-xs">
                        View Photos
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-6 flex flex-col md:flex-row gap-4">
            <div className="md:w-1/2 bg-gray-50 rounded-lg p-4">
              <h3 className="font-semibold mb-3">Journey Stats</h3>
              <div className="grid grid-cols-3 gap-3 text-center">
                <div className="bg-white p-3 rounded-lg">
                  <div className="text-xl font-bold text-soul-maroon">7</div>
                  <div className="text-xs text-gray-500">Sites Visited</div>
                </div>
                <div className="bg-white p-3 rounded-lg">
                  <div className="text-xl font-bold text-soul-orange">3</div>
                  <div className="text-xs text-gray-500">Cities</div>
                </div>
                <div className="bg-white p-3 rounded-lg">
                  <div className="text-xl font-bold text-soul-teal">12</div>
                  <div className="text-xs text-gray-500">Days</div>
                </div>
              </div>
            </div>
            
            <div className="md:w-1/2 bg-gray-50 rounded-lg p-4">
              <div className="flex justify-between items-center mb-3">
                <h3 className="font-semibold">Wishlist</h3>
                <Button variant="ghost" size="sm" className="h-8 text-xs">
                  View All
                </Button>
              </div>
              <div className="space-y-2">
                <div className="flex items-center bg-white p-2 rounded-lg">
                  <Heart className="h-4 w-4 text-soul-maroon mr-2" />
                  <span className="text-sm">Golden Temple, Amritsar</span>
                  <ChevronRight className="h-4 w-4 text-gray-400 ml-auto" />
                </div>
                <div className="flex items-center bg-white p-2 rounded-lg">
                  <Heart className="h-4 w-4 text-soul-maroon mr-2" />
                  <span className="text-sm">Khajuraho Temples</span>
                  <ChevronRight className="h-4 w-4 text-gray-400 ml-auto" />
                </div>
              </div>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="upcoming" className="p-4 mt-0">
          <div className="space-y-4">
            {upcomingEvents.map((event) => (
              <div key={event.id} className="flex border rounded-lg overflow-hidden shadow-sm">
                <div className="w-[150px] h-[100px]">
                  <img 
                    src={event.image} 
                    alt={event.name} 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-grow p-4">
                  <div className="flex justify-between">
                    <div>
                      <h3 className="font-semibold">{event.name}</h3>
                      <div className="flex items-center text-sm text-gray-500 mb-1">
                        <Map className="h-3 w-3 mr-1" />
                        <span>{event.location}</span>
                      </div>
                      <div className="flex items-center text-xs text-gray-500">
                        <Calendar className="h-3 w-3 mr-1" />
                        <span>{event.date}</span>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <Button className="bg-soul-orange hover:bg-soul-orange/90" size="sm">
                        Add to Itinerary
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-6">
            <h3 className="font-semibold mb-3">Recommended Based on Your Interests</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="border rounded-lg overflow-hidden">
                <div className="h-32 overflow-hidden">
                  <img 
                    src="https://images.unsplash.com/photo-1548013146-72479768bada?auto=format&fit=crop&q=80&w=300&h=150" 
                    alt="Taj Mahotsav" 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-3">
                  <h4 className="font-medium">Taj Mahotsav</h4>
                  <div className="flex justify-between items-center text-xs text-gray-500">
                    <div className="flex items-center">
                      <Calendar className="h-3 w-3 mr-1" />
                      <span>Feb 18-27, 2024</span>
                    </div>
                    <Badge className="bg-soul-gold">94% Match</Badge>
                  </div>
                </div>
              </div>
              
              <div className="border rounded-lg overflow-hidden">
                <div className="h-32 overflow-hidden">
                  <img 
                    src="https://images.unsplash.com/photo-1613576386924-fc82c3a2e98a?auto=format&fit=crop&q=80&w=300&h=150" 
                    alt="Holi Festival" 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-3">
                  <h4 className="font-medium">Holi Festival in Mathura</h4>
                  <div className="flex justify-between items-center text-xs text-gray-500">
                    <div className="flex items-center">
                      <Calendar className="h-3 w-3 mr-1" />
                      <span>Mar 25, 2024</span>
                    </div>
                    <Badge className="bg-soul-gold">89% Match</Badge>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default UserProfile;


import { ReactNode } from "react";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

interface OfflineContentCardProps {
  icon: ReactNode;
  title: string;
  description: string;
  progressValue: number;
  statusText: string;
  badgeType: "available" | "partial";
}

const OfflineContentCard = ({
  icon,
  title,
  description,
  progressValue,
  statusText,
  badgeType
}: OfflineContentCardProps) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
      <div className="flex items-center justify-between mb-4">
        <div className="rounded-full bg-soul-teal/10 p-2">
          {icon}
        </div>
        <Badge className={`${badgeType === "available" ? "bg-green-100 text-green-700 hover:bg-green-100" : "bg-amber-100 text-amber-700 hover:bg-amber-100"}`}>
          {badgeType === "available" ? "Available Offline" : "Partial Offline"}
        </Badge>
      </div>
      <h3 className="text-lg font-semibold mb-1">{title}</h3>
      <p className="text-gray-600 text-sm mb-4">
        {description}
      </p>
      <Progress value={progressValue} className="h-1.5 mb-2" />
      <div className="text-xs text-gray-500">{statusText}</div>
    </div>
  );
};

export default OfflineContentCard;

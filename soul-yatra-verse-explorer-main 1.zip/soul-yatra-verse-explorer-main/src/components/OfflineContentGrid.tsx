
import { Download, MessageSquare, Camera, Clock } from "lucide-react";
import OfflineContentCard from "./OfflineContentCard";

const OfflineContentGrid = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      <OfflineContentCard 
        icon={<Download className="h-5 w-5 text-soul-teal" />}
        title="Offline Maps"
        description="Download maps of heritage sites for offline navigation in areas with limited connectivity."
        progressValue={75}
        statusText="3 areas downloaded • 28MB used"
        badgeType="available"
      />
      
      <OfflineContentCard 
        icon={<MessageSquare className="h-5 w-5 text-soul-orange" />}
        title="Etiquette Guide"
        description="Access cultural etiquette tips even without internet connection for 15 countries."
        progressValue={40}
        statusText="15 countries saved • 12MB used"
        badgeType="available"
      />
      
      <OfflineContentCard 
        icon={<Camera className="h-5 w-5 text-soul-maroon" />}
        title="AR Models"
        description="3D models of key heritage sites available for offline augmented reality viewing."
        progressValue={25}
        statusText="2 models downloaded • 85MB used"
        badgeType="partial"
      />
      
      <OfflineContentCard 
        icon={<Clock className="h-5 w-5 text-soul-gold" />}
        title="Time Travel"
        description="Historical images and information about heritage sites through different time periods."
        progressValue={15}
        statusText="1 site downloaded • 45MB used"
        badgeType="partial"
      />
    </div>
  );
};

export default OfflineContentGrid;

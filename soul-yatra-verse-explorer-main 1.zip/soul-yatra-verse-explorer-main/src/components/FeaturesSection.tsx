
import { 
  Map, 
  Globe, 
  Compass, 
  Calendar, 
  UserCheck, 
  Headphones,
  Smartphone,
  Camera,
  Layers
} from "lucide-react";

const features = [
  {
    icon: <Map className="h-8 w-8 text-soul-orange" />,
    title: "Interactive Maps",
    description: "Explore heritage sites with detailed maps showing distances and nearby attractions."
  },
  {
    icon: <Globe className="h-8 w-8 text-soul-orange" />,
    title: "Language Translation",
    description: "Instant translation of local languages to help you communicate and understand cultural context."
  },
  {
    icon: <Compass className="h-8 w-8 text-soul-orange" />,
    title: "Nearby Explorer",
    description: "Discover hidden gems and authentic local experiences around any cultural site."
  },
  {
    icon: <Calendar className="h-8 w-8 text-soul-orange" />,
    title: "Events & Festivals",
    description: "Never miss local cultural celebrations with our comprehensive events calendar."
  },
  {
    icon: <Camera className="h-8 w-8 text-soul-orange" />,
    title: "Cultural AR/VR",
    description: "Experience 3D models and augmented reality views of heritage sites and artifacts."
  },
  {
    icon: <UserCheck className="h-8 w-8 text-soul-orange" />,
    title: "Cultural Etiquette",
    description: "Learn local customs and traditions to ensure respectful tourism in any destination."
  },
  {
    icon: <Layers className="h-8 w-8 text-soul-orange" />,
    title: "Time Travel Mode",
    description: "Visualize historical sites as they existed in different eras through digital recreations."
  },
  {
    icon: <Headphones className="h-8 w-8 text-soul-orange" />,
    title: "Local Voice Tours",
    description: "Audio guides narrated by local experts sharing authentic cultural knowledge."
  },
  {
    icon: <Smartphone className="h-8 w-8 text-soul-orange" />,
    title: "Offline Access",
    description: "Download guides and maps for offline use in remote areas with limited connectivity."
  }
];

const FeaturesSection = () => {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl font-bold mb-3">Discover SoulYatra Features</h2>
          <p className="text-gray-600">
            Our comprehensive cultural tourism platform offers tools to enhance your heritage exploration and cultural immersion
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="bg-white p-6 rounded-lg shadow-sm border border-gray-100 hover:shadow-md transition-shadow duration-300"
            >
              <div className="rounded-full bg-soul-orange/10 w-16 h-16 flex items-center justify-center mb-4">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;

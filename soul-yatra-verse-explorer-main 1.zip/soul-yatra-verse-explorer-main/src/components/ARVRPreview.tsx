
import { useState } from "react";
import { Layers, Smartphone, Camera, ArrowRight, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const ARVRPreview = () => {
  const [activeMode, setActiveMode] = useState<'ar' | 'vr'>('ar');
  
  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center justify-center rounded-full bg-soul-teal/10 p-2 mb-4">
            <Layers className="h-6 w-6 text-soul-teal" />
          </div>
          <h2 className="text-3xl font-bold mb-3">Experience in 3D</h2>
          <p className="text-gray-600">
            Explore heritage sites and cultural landmarks in immersive augmented and virtual reality
          </p>
        </div>
        
        <div className="bg-white rounded-xl shadow-lg overflow-hidden max-w-5xl mx-auto">
          <div className="flex flex-col md:flex-row">
            <div className="md:w-1/2 p-8">
              <div className="flex space-x-3 mb-6">
                <Button 
                  variant={activeMode === 'ar' ? "default" : "outline"}
                  className={activeMode === 'ar' ? "bg-soul-teal hover:bg-soul-teal/90" : "border-soul-teal text-soul-teal hover:bg-soul-teal/10"}
                  onClick={() => setActiveMode('ar')}
                >
                  <Camera className="mr-2 h-4 w-4" />
                  AR Mode
                </Button>
                <Button 
                  variant={activeMode === 'vr' ? "default" : "outline"}
                  className={activeMode === 'vr' ? "bg-soul-teal hover:bg-soul-teal/90" : "border-soul-teal text-soul-teal hover:bg-soul-teal/10"}
                  onClick={() => setActiveMode('vr')}
                >
                  <Eye className="mr-2 h-4 w-4" />
                  VR Mode
                </Button>
              </div>
              
              {activeMode === 'ar' ? (
                <div>
                  <h3 className="text-2xl font-bold mb-3">Augmented Reality Mode</h3>
                  <p className="text-gray-600 mb-4">
                    Point your camera at monuments to see informative overlays and reconstructions of how structures 
                    appeared in their original form.
                  </p>
                  
                  <div className="space-y-3 mb-6">
                    <div className="flex items-start">
                      <Badge className="mt-1 mr-2 bg-soul-teal">1</Badge>
                      <span className="text-gray-700">Point camera at a heritage site or marker</span>
                    </div>
                    <div className="flex items-start">
                      <Badge className="mt-1 mr-2 bg-soul-teal">2</Badge>
                      <span className="text-gray-700">See 3D models and historical information appear</span>
                    </div>
                    <div className="flex items-start">
                      <Badge className="mt-1 mr-2 bg-soul-teal">3</Badge>
                      <span className="text-gray-700">Interact with elements to learn more</span>
                    </div>
                  </div>
                </div>
              ) : (
                <div>
                  <h3 className="text-2xl font-bold mb-3">Virtual Reality Experience</h3>
                  <p className="text-gray-600 mb-4">
                    Immerse yourself in a 360° recreation of heritage sites. Walk around and explore 
                    cultural landmarks from anywhere in the world.
                  </p>
                  
                  <div className="space-y-3 mb-6">
                    <div className="flex items-start">
                      <Badge className="mt-1 mr-2 bg-soul-teal">1</Badge>
                      <span className="text-gray-700">Select a heritage site from our VR library</span>
                    </div>
                    <div className="flex items-start">
                      <Badge className="mt-1 mr-2 bg-soul-teal">2</Badge>
                      <span className="text-gray-700">Use your VR headset or phone in a mobile viewer</span>
                    </div>
                    <div className="flex items-start">
                      <Badge className="mt-1 mr-2 bg-soul-teal">3</Badge>
                      <span className="text-gray-700">Explore the site with full 360° movement</span>
                    </div>
                  </div>
                </div>
              )}
              
              <Button className="w-full mt-4 bg-soul-teal hover:bg-soul-teal/90">
                {activeMode === 'ar' ? "Try AR Experience" : "Enter VR Mode"} 
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
            
            <div className="md:w-1/2 bg-gray-100 relative">
              <div className="relative h-[300px] md:h-full overflow-hidden">
                <img 
                  src={activeMode === 'ar' 
                    ? "https://images.unsplash.com/photo-1626379953822-baec19c3accd?auto=format&fit=crop&q=80&w=600&h=700" 
                    : "https://images.unsplash.com/photo-1622979135225-d2ba269cf1ac?auto=format&fit=crop&q=80&w=600&h=700"
                  } 
                  alt={activeMode === 'ar' ? "AR Experience" : "VR Experience"} 
                  className="w-full h-full object-cover"
                />
                
                {activeMode === 'ar' && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="bg-white/80 backdrop-blur-sm p-4 rounded-lg max-w-[200px] shadow-lg">
                      <h4 className="font-semibold text-soul-maroon">Qutub Minar</h4>
                      <p className="text-xs text-gray-700">Built in 1192 by Qutb-ud-din Aibak</p>
                      <div className="mt-2 text-xs flex justify-between text-gray-600">
                        <span>Height: 73m</span>
                        <span>UNESCO Site</span>
                      </div>
                    </div>
                  </div>
                )}
                
                {activeMode === 'vr' && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="border-4 border-white rounded-full h-16 w-16 flex items-center justify-center">
                      <div className="animate-pulse h-10 w-10 bg-white rounded-full flex items-center justify-center">
                        <Eye className="h-5 w-5 text-soul-teal" />
                      </div>
                    </div>
                  </div>
                )}
              </div>
              
              <div className="absolute bottom-4 left-4 bg-black/70 text-white text-xs px-3 py-1 rounded-full backdrop-blur-sm flex items-center">
                <Smartphone className="h-3 w-3 mr-1" />
                {activeMode === 'ar' ? "Point camera to scan" : "Turn phone for 360° view"}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ARVRPreview;


import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";

const EnhancedOfflineExperience = () => {
  return (
    <div className="bg-soul-cream/30 rounded-lg p-6 border border-soul-orange/20">
      <div className="flex items-start">
        <div className="rounded-full bg-soul-orange/20 p-3 mr-4">
          <Download className="h-6 w-6 text-soul-orange" />
        </div>
        <div>
          <h3 className="text-xl font-bold mb-2">Enhanced Offline Experience</h3>
          <p className="text-gray-700 mb-4">
            Download cultural content, maps, and guides to ensure a seamless experience even in areas with limited connectivity.
            Access AR models, etiquette tips, and more without internet access.
          </p>
          <div className="flex flex-wrap gap-3">
            <Button className="bg-soul-orange hover:bg-soul-orange/90">
              <Download className="h-4 w-4 mr-2" />
              Download Essential Pack (175MB)
            </Button>
            <Button variant="outline" className="border-soul-orange text-soul-orange hover:bg-soul-orange/10">
              Manage Offline Content
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EnhancedOfflineExperience;

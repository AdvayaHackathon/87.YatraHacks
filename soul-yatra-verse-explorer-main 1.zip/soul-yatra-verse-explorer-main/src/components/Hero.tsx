
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "@/components/ui/use-toast";

const Hero = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const navigate = useNavigate();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!searchQuery.trim()) {
      toast({
        title: "Search Error",
        description: "Please enter a search term",
        variant: "destructive"
      });
      return;
    }
    
    // Navigate to search results (map page with query)
    navigate(`/map?q=${encodeURIComponent(searchQuery)}`);
  };

  return (
    <div className="relative overflow-hidden bg-gradient-to-b from-soul-cream to-white py-16 md:py-24">
      {/* Decorative background elements */}
      <div className="absolute inset-0 pattern-overlay"></div>
      <div className="absolute top-20 left-10 w-16 h-16 bg-soul-gold/20 rounded-full blur-xl"></div>
      <div className="absolute bottom-20 right-10 w-24 h-24 bg-soul-teal/15 rounded-full blur-xl"></div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            <span className="bg-gradient-to-r from-soul-maroon to-soul-orange bg-clip-text text-transparent">
              Discover the Soul
            </span>{" "}
            of Culture
          </h1>
          
          <p className="text-lg md:text-xl text-gray-700 mb-8">
            Explore heritage sites, immerse in local traditions, and embark on
            a journey through time and culture.
          </p>

          <form onSubmit={handleSearch} className="relative max-w-lg mx-auto mb-10">
            <Input
              type="text"
              placeholder="Search for a destination or cultural experience..."
              className="pl-4 pr-12 py-6 rounded-full bg-white shadow-lg border-soul-teal/20"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Button 
              type="submit" 
              size="icon" 
              className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-soul-orange hover:bg-soul-orange/90 rounded-full h-10 w-10"
            >
              <Search className="h-5 w-5" />
            </Button>
          </form>

          <div className="flex flex-wrap justify-center gap-4">
            <Button variant="outline" className="rounded-full border-soul-maroon text-soul-maroon hover:bg-soul-maroon/10">
              UNESCO Sites
            </Button>
            <Button variant="outline" className="rounded-full border-soul-gold text-soul-gold hover:bg-soul-gold/10">
              Festivals
            </Button>
            <Button variant="outline" className="rounded-full border-soul-teal text-soul-teal hover:bg-soul-teal/10">
              Local Cuisine
            </Button>
            <Button variant="outline" className="rounded-full border-soul-orange text-soul-orange hover:bg-soul-orange/10">
              Traditional Arts
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;

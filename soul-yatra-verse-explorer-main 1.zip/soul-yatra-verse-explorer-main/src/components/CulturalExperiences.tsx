
import { useState } from "react";
import { CalendarIcon, Clock, User, MapPin, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";

// Sample data - would come from an API in real implementation
const experiences = [
  {
    id: 1,
    title: "Traditional Pottery Workshop",
    location: "Jaipur, India",
    image: "https://images.unsplash.com/photo-1493106641515-6b5631de4bb9?auto=format&fit=crop&q=80&w=600&h=400",
    duration: "3 hours",
    price: "₹1200",
    participants: "Small group",
    date: "Available daily"
  },
  {
    id: 2,
    title: "Ancient Temple Meditation",
    location: "Kyoto, Japan",
    image: "https://images.unsplash.com/photo-1613978541398-c48cc1b02dad?auto=format&fit=crop&q=80&w=600&h=400",
    duration: "2 hours",
    price: "¥3000",
    participants: "Max 6 people",
    date: "Weekends only"
  },
  {
    id: 3,
    title: "Traditional Tea Ceremony",
    location: "Hangzhou, China",
    image: "https://images.unsplash.com/photo-1558160074-4d7d8bdf4256?auto=format&fit=crop&q=80&w=600&h=400",
    duration: "1.5 hours",
    price: "¥400",
    participants: "Small group",
    date: "Tue, Thu, Sat"
  }
];

const CulturalExperiences = () => {
  return (
    <section className="py-16 bg-soul-cream/50">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-10">
          <div>
            <h2 className="text-3xl font-bold mb-2">Authentic Cultural Experiences</h2>
            <p className="text-gray-600 max-w-2xl">
              Immerse yourself in traditional arts, crafts, and ceremonies guided by local cultural experts
            </p>
          </div>
          <Button 
            variant="link" 
            className="text-soul-maroon mt-2 md:mt-0 flex items-center"
          >
            Browse all experiences
            <ArrowRight className="ml-1 h-4 w-4" />
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {experiences.map((exp) => (
            <Card key={exp.id} className="cultural-card overflow-hidden flex flex-col">
              <div className="relative h-52 overflow-hidden">
                <img 
                  src={exp.image} 
                  alt={exp.title}
                  className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                />
              </div>
              
              <CardContent className="pt-5 pb-3 flex-grow">
                <h3 className="text-xl font-semibold mb-2">{exp.title}</h3>
                <div className="flex items-center text-gray-600 mb-2">
                  <MapPin className="h-4 w-4 mr-1" />
                  <span className="text-sm">{exp.location}</span>
                </div>
                
                <div className="grid grid-cols-2 gap-2 text-sm text-gray-600 mt-4">
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-1 text-soul-maroon" />
                    <span>{exp.duration}</span>
                  </div>
                  <div className="flex items-center">
                    <User className="h-4 w-4 mr-1 text-soul-maroon" />
                    <span>{exp.participants}</span>
                  </div>
                  <div className="flex items-center">
                    <CalendarIcon className="h-4 w-4 mr-1 text-soul-maroon" />
                    <span>{exp.date}</span>
                  </div>
                  <div className="font-medium text-soul-maroon">
                    {exp.price}
                  </div>
                </div>
              </CardContent>
              
              <CardFooter className="pt-2 pb-5 flex justify-between border-t">
                <Button variant="outline" className="border-soul-orange text-soul-orange hover:bg-soul-orange/10">
                  Learn more
                </Button>
                <Button className="bg-soul-orange hover:bg-soul-orange/90">
                  Book now
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CulturalExperiences;

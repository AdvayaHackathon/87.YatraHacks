
import { useState } from "react";
import { MessageSquare, Info, ThumbsUp, ThumbsDown, BookOpen, Clock, Download, Lightbulb, MessageCircle, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent } from "@/components/ui/card";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

interface EtiquetteTip {
  id: number;
  country: string;
  category: string;
  title: string;
  description: string;
  doList: string[];
  dontList: string[];
}

const etiquetteTips: EtiquetteTip[] = [
  {
    id: 1,
    country: "India",
    category: "Temples",
    title: "Temple Etiquette in India",
    description: "Hindu temples are sacred spaces with specific customs and expectations for visitors.",
    doList: [
      "Remove your shoes before entering",
      "Dress modestly covering shoulders and knees",
      "Walk clockwise around sacred objects",
      "Accept prasad (offerings) with your right hand"
    ],
    dontList: [
      "Don't take photos without permission",
      "Don't touch statues or artifacts",
      "Don't display affection publicly inside temples",
      "Don't point your feet toward deities or people"
    ]
  },
  {
    id: 2,
    country: "India",
    category: "Dining",
    title: "Dining Customs in India",
    description: "Indian dining customs vary by region but share some common traditions.",
    doList: [
      "Wash hands before and after meals",
      "Use your right hand for eating if eating with hands",
      "Wait for elders to start eating before you begin",
      "Express appreciation for the food"
    ],
    dontList: [
      "Don't waste food on your plate",
      "Don't leave the table before elders",
      "Don't use your left hand for eating or passing food",
      "Don't lick your fingers in formal settings"
    ]
  },
  {
    id: 3,
    country: "India",
    category: "Greetings",
    title: "Greeting Etiquette in India",
    description: "The traditional Indian greeting is the Namaste, with specific protocols based on context.",
    doList: [
      "Use 'Namaste' with palms together and a slight bow",
      "Address older people with respect using 'Ji' after their name",
      "Wait for someone to extend their hand before shaking hands",
      "Remove shoes when entering someone's home"
    ],
    dontList: [
      "Don't hug or kiss in greeting, especially with the opposite gender",
      "Don't touch someone's head as it's considered sacred",
      "Don't rush greetings, take time for pleasantries",
      "Don't use overly casual language with elders"
    ]
  }
];

interface ChatMessage {
  id: number;
  sender: 'user' | 'coach';
  text: string;
  timestamp: Date;
}

const CulturalEtiquetteCoach = () => {
  const [activeTab, setActiveTab] = useState<'tips' | 'coach'>('tips');
  const [expandedTipId, setExpandedTipId] = useState<number | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: 1,
      sender: 'coach',
      text: "Hello! I'm your Cultural Etiquette Coach. Ask me any questions about local customs, traditions, or etiquette during your travels.",
      timestamp: new Date()
    }
  ]);
  const [newMessage, setNewMessage] = useState("");
  const [isCoachTyping, setIsCoachTyping] = useState(false);
  const [savedTips, setSavedTips] = useState<number[]>([1]);
  
  const toggleExpandTip = (id: number) => {
    setExpandedTipId(expandedTipId === id ? null : id);
  };
  
  const toggleSaveTip = (id: number) => {
    if (savedTips.includes(id)) {
      setSavedTips(savedTips.filter(tipId => tipId !== id));
    } else {
      setSavedTips([...savedTips, id]);
    }
  };
  
  const handleSendMessage = () => {
    if (!newMessage.trim()) return;
    
    // Add user message
    const userMessage: ChatMessage = {
      id: chatMessages.length + 1,
      sender: 'user',
      text: newMessage,
      timestamp: new Date()
    };
    
    setChatMessages([...chatMessages, userMessage]);
    setNewMessage("");
    setIsCoachTyping(true);
    
    // Simulate AI response
    setTimeout(() => {
      let response = "";
      
      if (newMessage.toLowerCase().includes("temple")) {
        response = "When visiting temples in India, it's customary to remove your shoes before entering. Dress modestly with shoulders and knees covered. Avoid taking photos inside without permission, and never point your feet toward deities or other people.";
      } else if (newMessage.toLowerCase().includes("food") || newMessage.toLowerCase().includes("eat") || newMessage.toLowerCase().includes("dining")) {
        response = "In traditional Indian dining, many people eat with their right hand. If offered food, it's polite to accept at least a small portion. When dining in someone's home, wait for the host to begin eating before you start.";
      } else if (newMessage.toLowerCase().includes("greeting") || newMessage.toLowerCase().includes("namaste")) {
        response = "The traditional Indian greeting is 'Namaste,' performed by pressing your palms together at chest level with a slight bow. It's a respectful way to greet people of all ages and statuses.";
      } else {
        response = "That's a great question about Indian culture! When in doubt, observe locals and follow their lead. Showing respect for local customs is always appreciated. Would you like to know about any specific aspect of etiquette like temple visits, dining, or greetings?";
      }
      
      const coachMessage: ChatMessage = {
        id: chatMessages.length + 2,
        sender: 'coach',
        text: response,
        timestamp: new Date()
      };
      
      setChatMessages(prev => [...prev, coachMessage]);
      setIsCoachTyping(false);
    }, 1500);
  };
  
  const filteredTips = etiquetteTips.filter(tip => 
    tip.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    tip.country.toLowerCase().includes(searchTerm.toLowerCase()) ||
    tip.category.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  return (
    <div className="min-h-[600px] flex flex-col">
      <div className="bg-soul-maroon text-white p-4 flex justify-between items-center">
        <h2 className="font-bold text-lg">Cultural Etiquette Coach</h2>
        <div className="flex gap-2">
          <Button 
            variant={activeTab === 'tips' ? "secondary" : "ghost"} 
            size="sm"
            className="text-white hover:text-white hover:bg-white/20"
            onClick={() => setActiveTab('tips')}
          >
            <BookOpen className="h-4 w-4 mr-1" />
            Etiquette Tips
          </Button>
          <Button 
            variant={activeTab === 'coach' ? "secondary" : "ghost"} 
            size="sm"
            className="text-white hover:text-white hover:bg-white/20"
            onClick={() => setActiveTab('coach')}
          >
            <MessageSquare className="h-4 w-4 mr-1" />
            Ask Coach
          </Button>
        </div>
      </div>
      
      {activeTab === 'tips' && (
        <div className="flex-grow p-4 overflow-auto">
          <div className="mb-4">
            <Input
              type="text"
              placeholder="Search by country, category, or keyword..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full"
            />
          </div>
          
          <div className="space-y-4">
            {filteredTips.length > 0 ? (
              filteredTips.map(tip => (
                <Card key={tip.id} className="overflow-hidden">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <Badge className="bg-soul-teal mb-2">{tip.country}</Badge>
                        <Badge variant="outline" className="ml-2 mb-2">{tip.category}</Badge>
                        <h3 className="font-semibold text-lg">{tip.title}</h3>
                      </div>
                      <Button 
                        variant="ghost" 
                        size="icon"
                        className={savedTips.includes(tip.id) ? "text-soul-orange" : "text-gray-400"}
                        onClick={() => toggleSaveTip(tip.id)}
                      >
                        <BookOpen className="h-5 w-5" />
                      </Button>
                    </div>
                    
                    <p className="text-gray-600 mb-3">{tip.description}</p>
                    
                    <Collapsible open={expandedTipId === tip.id} onOpenChange={() => toggleExpandTip(tip.id)}>
                      <CollapsibleTrigger asChild>
                        <Button variant="outline" size="sm" className="w-full">
                          {expandedTipId === tip.id ? "Show Less" : "View Guidelines"}
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-3">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="bg-green-50 p-3 rounded-md">
                            <h4 className="font-medium text-green-700 mb-2">Do's</h4>
                            <ul className="space-y-2">
                              {tip.doList.map((item, index) => (
                                <li key={index} className="flex items-center text-sm text-gray-700">
                                  <ThumbsUp className="h-4 w-4 text-green-600 mr-2 flex-shrink-0" />
                                  <span>{item}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                          <div className="bg-red-50 p-3 rounded-md">
                            <h4 className="font-medium text-red-700 mb-2">Don'ts</h4>
                            <ul className="space-y-2">
                              {tip.dontList.map((item, index) => (
                                <li key={index} className="flex items-center text-sm text-gray-700">
                                  <ThumbsDown className="h-4 w-4 text-red-600 mr-2 flex-shrink-0" />
                                  <span>{item}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                        <div className="flex justify-between mt-3">
                          <Button variant="ghost" size="sm" className="text-soul-teal">
                            <Download className="h-4 w-4 mr-1" />
                            Save Offline
                          </Button>
                          <Button size="sm" className="bg-soul-orange hover:bg-soul-orange/90">
                            <MessageCircle className="h-4 w-4 mr-1" />
                            Ask Coach
                          </Button>
                        </div>
                      </CollapsibleContent>
                    </Collapsible>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="text-center py-12">
                <Info className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-1">No tips found</h3>
                <p className="text-gray-500">Try adjusting your search or browse all tips</p>
              </div>
            )}
          </div>
          
          {filteredTips.length > 0 && (
            <div className="mt-6 bg-gray-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-3">Quick Culture Tip</h3>
              <div className="flex items-start">
                <Lightbulb className="h-8 w-8 text-soul-gold mr-3 flex-shrink-0" />
                <div>
                  <p className="text-gray-700 mb-2">
                    "In India, it's considered respectful to accept food or gifts with your right hand. 
                    The left hand is traditionally considered less clean in Indian culture."
                  </p>
                  <div className="text-xs text-gray-500">Source: Indian Cultural Heritage Foundation</div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
      
      {activeTab === 'coach' && (
        <div className="flex-grow flex flex-col">
          <div className="flex-grow overflow-auto p-4 bg-gray-50">
            {chatMessages.map(message => (
              <div
                key={message.id}
                className={`mb-4 flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {message.sender === 'coach' && (
                  <Avatar className="h-8 w-8 mr-2">
                    <AvatarImage src="https://i.imgur.com/LFjN3tu.png" />
                    <AvatarFallback>EC</AvatarFallback>
                  </Avatar>
                )}
                <div 
                  className={`max-w-[80%] rounded-lg px-4 py-2 ${
                    message.sender === 'user' 
                      ? 'bg-soul-maroon text-white' 
                      : 'bg-white border'
                  }`}
                >
                  <div className="mb-1">{message.text}</div>
                  <div 
                    className={`text-xs ${message.sender === 'user' ? 'text-white/70' : 'text-gray-500'}`}
                  >
                    {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
                {message.sender === 'user' && (
                  <Avatar className="h-8 w-8 ml-2">
                    <AvatarImage src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150&h=150" />
                    <AvatarFallback>VS</AvatarFallback>
                  </Avatar>
                )}
              </div>
            ))}
            
            {isCoachTyping && (
              <div className="flex items-center mb-4">
                <Avatar className="h-8 w-8 mr-2">
                  <AvatarImage src="https://i.imgur.com/LFjN3tu.png" />
                  <AvatarFallback>EC</AvatarFallback>
                </Avatar>
                <div className="bg-white border rounded-lg px-4 py-2">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-75"></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-150"></div>
                  </div>
                </div>
              </div>
            )}
          </div>
          
          <div className="p-3 border-t bg-white">
            <div className="mb-2 flex items-center justify-between">
              <div className="text-xs text-gray-500 flex items-center">
                <Clock className="h-3 w-3 mr-1" />
                <span>Offline mode available</span>
              </div>
              <Button variant="ghost" size="sm" className="h-6 text-xs">
                <Download className="h-3 w-3 mr-1" />
                Save for Offline
              </Button>
            </div>
            
            <div className="flex gap-2">
              <Input
                type="text"
                placeholder="Ask about local customs and etiquette..."
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                className="flex-grow"
              />
              <Button 
                className="bg-soul-maroon hover:bg-soul-maroon/90" 
                onClick={handleSendMessage}
                disabled={!newMessage.trim() || isCoachTyping}
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
            
            <div className="mt-2 flex flex-wrap gap-1">
              <Button variant="ghost" size="sm" className="text-xs h-6 py-0" onClick={() => setNewMessage("What should I know about visiting temples in India?")}>
                Temple etiquette
              </Button>
              <Button variant="ghost" size="sm" className="text-xs h-6 py-0" onClick={() => setNewMessage("How do I greet people in India?")}>
                Greeting customs
              </Button>
              <Button variant="ghost" size="sm" className="text-xs h-6 py-0" onClick={() => setNewMessage("What are the dining etiquette rules in India?")}>
                Dining etiquette
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CulturalEtiquetteCoach;


import { Link } from "react-router-dom";
import { 
  Facebook, 
  Twitter, 
  Instagram, 
  Youtube,
  Mail,
  Phone,
  MapPin
} from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-soul-brown text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-10 h-10 bg-soul-orange rounded-full flex items-center justify-center">
                <span className="text-white font-display text-xl font-bold">S</span>
              </div>
              <span className="text-xl font-display font-bold text-white">
                SoulYatra
              </span>
            </div>
            
            <p className="text-gray-300 mb-4">
              Discover the soul of cultures around the world. Embark on journeys that connect you with heritage, traditions, and authentic experiences.
            </p>
            
            <div className="flex space-x-4">
              <a href="#" className="text-white hover:text-soul-orange">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-white hover:text-soul-orange">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-white hover:text-soul-orange">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-white hover:text-soul-orange">
                <Youtube className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-300 hover:text-white">Home</Link>
              </li>
              <li>
                <Link to="/explore" className="text-gray-300 hover:text-white">Heritage Sites</Link>
              </li>
              <li>
                <Link to="/map" className="text-gray-300 hover:text-white">Interactive Map</Link>
              </li>
              <li>
                <Link to="/translate" className="text-gray-300 hover:text-white">Translation Tools</Link>
              </li>
              <li>
                <Link to="/events" className="text-gray-300 hover:text-white">Cultural Events</Link>
              </li>
              <li>
                <Link to="/login" className="text-gray-300 hover:text-white">Sign In / Register</Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Features</h3>
            <ul className="space-y-2">
              <li className="text-gray-300 hover:text-white">Cultural AR/VR</li>
              <li className="text-gray-300 hover:text-white">Local Voice Tours</li>
              <li className="text-gray-300 hover:text-white">Time Travel Mode</li>
              <li className="text-gray-300 hover:text-white">Cultural Etiquette</li>
              <li className="text-gray-300 hover:text-white">Language Translation</li>
              <li className="text-gray-300 hover:text-white">Offline Access</li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <MapPin className="h-5 w-5 mr-2 mt-0.5 text-soul-orange" />
                <span className="text-gray-300">
                  123 Cultural Avenue, Heritage District, World City
                </span>
              </li>
              <li className="flex items-center">
                <Phone className="h-5 w-5 mr-2 text-soul-orange" />
                <span className="text-gray-300">+1 (123) 456-7890</span>
              </li>
              <li className="flex items-center">
                <Mail className="h-5 w-5 mr-2 text-soul-orange" />
                <span className="text-gray-300">info@soulyatra.com</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-12 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm mb-4 md:mb-0">
            &copy; {new Date().getFullYear()} SoulYatra. All rights reserved.
          </p>
          
          <div className="flex space-x-6">
            <Link to="/privacy" className="text-gray-400 text-sm hover:text-white">
              Privacy Policy
            </Link>
            <Link to="/terms" className="text-gray-400 text-sm hover:text-white">
              Terms of Service
            </Link>
            <Link to="/cookie" className="text-gray-400 text-sm hover:text-white">
              Cookie Policy
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
